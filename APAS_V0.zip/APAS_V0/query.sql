﻿create database QLGX
go
use QLGX
go

create table khuVuc(
	maKhuVuc varchar(10) primary key,
	tenKhuVuc nvarchar(30),
	loaiXe int,--0: xe may', 1: xe may dien, 2: o to, 3: o to dien, 4: xe dap
	tongSoCho int,
	soChoKhaDung int,
	tinhTrang int --0 hoat dong, 1 bao tri
) 
go

create table nhanVien(
	maNV varchar(10) primary key,
	maKhuVuc varchar(10) foreign key references KhuVuc(maKhuVuc),
	hoTen nvarchar(50),
	sdt varchar(20),
	email varchar(30),
	chucVu int, --0: nhan vien xu ly du lieu, 1: nhan vien ke toan, 2: nhan vien quan ly khu vuc, 3: nhan vien an ninh
	trangThai int
)
go

create table SuCo(
	maSuCo varchar(10) primary key,
	maNV varchar(10) foreign key references nhanVien(maNV),
	moTa nvarchar(200),
	thoiGianBaoCao datetime,
	tinhTrangGiaiQuyet int
)
go

create table GiaoDich(
	maGiaoDich varchar(10) primary key,
	maNV varchar(10) foreign key references nhanVien(maNV),
	noiDung nvarchar(100),
	soTien int,
	tInhTrangXuLy int,
	thoIGian datetime,
)
go

create table ChiTieu(
	maChiTieu varchar(10) primary key,
	maNV varchar(10) foreign key references nhanVien(maNV),
	moTa nvarchar(100),
	ngayChiTieu date,
	SoTien int
)
go

create table DoanhThuVangLai(
	maDTVL varchar(10) primary key,
	thoIGianDoanhThu date,
	doanhThuXeMay int,
	doanhThuXeDap int,
	doanhThuOTo int
)
go

create table GiaGuiXe(
	maGiaGuiXe varchar(10) primary key,
	giaGuiXeMayDV int,
	giaGuiOToDV int,
	giaGuiXeDapDV int,
	giaGuiXeMayVL int,
	giaGuiXeHoiVL int,
	thoiGianThayDoi date
)
go

create table ThongKeGiaHan(
	maGiaHan varchar(10) primary key,
	thoiHan int,
	thoiGianXuLy datetime,
	loaiXe int
)
go

create table PhuongTienVangLai(
	soXeVangLai varchar(12) primary key,
	maKhuVuc varchar(10) foreign key references KhuVuc(maKhuVuc),
	thoiGianGuiYC datetime,
	maGuiXe varchar(5)
)
go




create table DangKyTaiKhoanDichVu(
	maYeuCau varchar(10) primary key,
	hoTen nvarchar(50),
	email varchar(50),
	sdt varchar(20),
	diachi nvarchar(50),
	bienSoXM varchar(12),
	mauSacXM nvarchar(20),
	hangXM nvarchar(20),
	nhienLieuXM nvarchar(10),
	bienSoOT varchar(12),
	mauSacOT nvarchar(20),
	hangOT nvarchar(20),
	nhienLieuOT nvarchar(10),
	guiXeDap int,
	tinhTrang int,
	maNV varchar(10) foreign key references nhanVien(maNV)
)
go

CREATE FUNCTION dbo.GenerateMaYeuCauDK()
RETURNS VARCHAR(10)
AS
BEGIN
    DECLARE @nextNumber INT;

    SELECT @nextNumber = ISNULL(MAX(CAST(SUBSTRING(maYeuCau, 3, LEN(maYeuCau)) AS INT)), 0) + 1
    FROM DangKyTaiKhoanDichVu;

    RETURN 'DK' + CAST(@nextNumber AS VARCHAR);
END;
go


CREATE PROCEDURE InsertYeuCauDangKy
    @hoTen NVARCHAR(50),
	@email VARCHAR(50),
    @sdt VARCHAR(20),
	@diachi nvarchar(50),
    @bienSoXM VARCHAR(12),
    @mauSacXM NVARCHAR(20),
    @hangXM NVARCHAR(20),
    @nhienLieuXM NVARCHAR(10),
    @bienSoOT VARCHAR(12),
    @mauSacOT NVARCHAR(20),
    @hangOT NVARCHAR(20),
    @nhienLieuOT NVARCHAR(10),
    @guiXeDap int
AS
BEGIN
    DECLARE @maYeuCau VARCHAR(10);
    SET @maYeuCau = dbo.GenerateMaYeuCauDK();
    INSERT INTO DangKyTaiKhoanDichVu (maYeuCau,hoTen,sdt,email,diachi,bienSoXM,mauSacXM,hangXM,nhienLieuXM,bienSoOT,mauSacOT,hangOT,nhienLieuOT,guiXeDap,tinhTrang)
    VALUES (@maYeuCau,@hoTen,@sdt,@email,@diachi,@bienSoXM,@mauSacXM,@hangXM,@nhienLieuXM,@bienSoOT,@mauSacOT,@hangOT,@nhienLieuOT,@guiXeDap,0);
END;
go

create table taiKhoanDichVu(
	tenDangNhap varchar(20) primary key,
	hashPassword varchar(50),
	email varchar(50),
	trangThai int
)
go

create table PhuongTien(
	soXe varchar(12) primary key,
	tenDangNhap varchar(20) foreign key references taiKhoanDichVu(tenDangNhap),
	maKhuVuc varchar(10) foreign key references khuVuc(maKhuVuc),
	mauSac nvarchar(20),
	hangXe nvarchar(30), 
	loaiXe int, --0: xe may', 1: xe may' dien, 2: o to xang, 3: o to dien
	thoiGianDangKy date,
	thoiGianHetHan date,
	maGuiXe varchar(5),
	trangThai int, --0: khong co trong bai, 1: dang gui trong bai~
	thoiGianGuiXe datetime,
	ghiChu nvarchar(50)
)
go

CREATE PROCEDURE InsertPhuongTien
    @soXe VARCHAR(12),
    @tenDangNhap VARCHAR(20),
    @maKhuVuc VARCHAR(10),
    @mauSac NVARCHAR(20),
    @hangXe NVARCHAR(30),
    @loaiXe INT
AS
BEGIN
    INSERT INTO PhuongTien (soXe,tenDangNhap,maKhuVuc,mauSac,hangXe,loaiXe,thoiGianDangKy,thoiGianHetHan,maGuiXe,trangThai,thoiGianGuiXe,ghiChu)
    VALUES (@soXe,@tenDangNhap,@maKhuVuc,@mauSac,@hangXe,@loaiXe,GETDATE(), GETDATE(), '',0, NULL, '');
	UPDATE KhuVuc
    SET soChoKhaDung = soChoKhaDung - 1 
    WHERE maKhuVuc = @maKhuVuc;
END
go

CREATE PROCEDURE InsertTaiKhoanDichVu
    @tenDangNhap VARCHAR(20),
    @hashPassword VARCHAR(50),
    @email VARCHAR(50)
AS
BEGIN
    INSERT INTO taiKhoanDichVu (tenDangNhap,hashPassword,email,trangThai)
    VALUES (@tenDangNhap,@hashPassword,@email,0);
END

go

create FUNCTION dbo.GetMaKhuVucForBicycle()
RETURNS VARCHAR(10)
AS
BEGIN
    DECLARE @result VARCHAR(10);

    SELECT TOP 1 @result = maKhuVuc
    FROM khuVuc
    WHERE soChoKhaDung > 0 AND loaiXe = 4;

    RETURN @result;
END

go


create PROCEDURE InsertQuanLyXeDap
    @taiKhoanSoHuu VARCHAR(20)
AS
BEGIN
    DECLARE @maKhuVuc VARCHAR(10);

    SET @maKhuVuc = dbo.GetMaKhuVucForBicycle();

    INSERT INTO QuanLyXeDap (taiKhoanSoHuu, thoiGianDangKy, thoiGianHetHan, trangThai, thoiGianGuiXe, ghiChu, maGuiXe, maKhuVuc)
    VALUES (@taiKhoanSoHuu, NULL, GETDATE(), 0, NULL, '', '', @maKhuVuc);

    UPDATE KhuVuc
    SET soChoKhaDung = soChoKhaDung - 1 
    WHERE maKhuVuc = @maKhuVuc;
END

go

create table resetPasswordDichVu(
	maYeuCau varchar(10) primary key,
	tenDangNhap varchar(20),
	resetToken varchar(10),
	thoiGianYeuCau datetime,
	trangThai int,
	foreign key(tenDangNhap) references TaiKhoanDichVu(tenDangNhap)
)
go

create table taiKhoanNhanVien(
	tenDangNhap varchar(20) primary key,
	maNV varchar(10) foreign key references nhanVien(maNV),
	password varchar(50),
	trangThai int,
	email varchar(30)
)

create table resetPasswordNhanVien(
	maYeuCau varchar(10) primary key,
	tenDangNhap varchar(20),
	resetToken varchar(10),
	thoiGianYeuCau datetime,
	trangThai int,
	foreign key(tenDangNhap) references taiKhoanNhanVien(tenDangNhap)
)

create table QuanLyXeDap(
	taiKhoanSoHuu varchar(20) primary key,
	thoiGianDangKy date,
	thoiGianHetHan date,
	trangThai int,--0: khong co trong bai, 1: dang gui trong bai~
	thoiGianGuiXe datetime,
	ghiChu nvarchar(50),
	maGuiXe varchar(5),
	maKhuVuc varchar(10) foreign key REFERENCES khuVuc(maKhuVuc),
	FOREIGN KEY (taiKhoanSoHuu) REFERENCES taiKhoanDichVu(tenDangNhap)
)
go

create table YeuCauDangKyThemDV(
	maYeuCauDKT varchar(10) primary key,
	soXe varchar(12),
	mauSac nvarchar(20),
	hangXe nvarchar(30), 
	loaiXe int,
	trangThai int,
	tenTaiKhoan varchar(20) foreign key references taiKhoanDichVu(TenDangNhap)
)
go

create table YeuCauHoTro(
	maYeuCauHT varchar(10) primary key,
	moTa nvarchar(100),
	thoiGianGuiYC datetime,
	tenTaiKhoan varchar(20) foreign key references taiKhoanDichVu(TenDangNhap),
	TrangThai int
)



--Test data

INSERT INTO taiKhoanDichVu (tenDangNhap, hashPassword, email, trangThai) VALUES
('0912345678', 'hashed_password_1', 'user1@example.com', 0),
('0987654321', 'hashed_password_2', 'user2@example.com', 0),
('0223456789', 'hashed_password_3', 'user3@example.com', 0),
('0876543210', 'hashed_password_4', 'user4@example.com', 0),
('0765432109', 'hashed_password_5', 'user5@example.com', 0);
go

INSERT INTO khuVuc (maKhuVuc, tenKhuVuc, loaiXe, tongSoCho, soChoKhaDung, tinhTrang)
VALUES ('KV001', N'Khu vực A', 0, 50, 49, 0);
INSERT INTO khuVuc (maKhuVuc, tenKhuVuc, loaiXe, tongSoCho, soChoKhaDung, tinhTrang)
VALUES ('KV002', N'Khu vực B', 1, 30, 30, 0);
INSERT INTO khuVuc (maKhuVuc, tenKhuVuc, loaiXe, tongSoCho, soChoKhaDung, tinhTrang)
VALUES ('KV003', N'Khu vực C', 2, 40, 40, 0);
INSERT INTO khuVuc (maKhuVuc, tenKhuVuc, loaiXe, tongSoCho, soChoKhaDung, tinhTrang)
VALUES ('KV004', N'Khu vực D', 3, 20, 0, 0);
INSERT INTO khuVuc (maKhuVuc, tenKhuVuc, loaiXe, tongSoCho, soChoKhaDung, tinhTrang)
VALUES ('KV005', N'Khu vực E', 4, 20, 15, 0);
INSERT INTO khuVuc (maKhuVuc, tenKhuVuc, loaiXe, tongSoCho, soChoKhaDung, tinhTrang) VALUES
('KV006', N'Khu vực F', 0, 80, 50, 0),
('KV007', N'Khu vực G', 1, 25, 5, 0),
('KV008', N'Khu vực H', 2, 120, 75, 0),
('KV009', N'Khu vực I', 3, 60, 0, 0), --O to dien khong co cho -> test
('KV010', N'Khu vực J', 4, 15, 2, 0);
go


EXEC InsertPhuongTien 
    @soXe = '29A12345', 
    @tenDangNhap = '0876543210', 
    @maKhuVuc = 'KV001', 
    @mauSac = N'Đỏ', 
    @hangXe = N'Honda', 
    @loaiXe = 0;
go
select * from PhuongTien
EXEC InsertPhuongTien 
    @soXe = '30F12345', 
    @tenDangNhap = '0987654321', 
    @maKhuVuc = 'KV003', 
    @mauSac = N'Vàng', 
    @hangXe = N'Toyota', 
    @loaiXe = 2;

go
EXEC InsertPhuongTien 
    @soXe = '30F67890', 
    @tenDangNhap = '0765432109', 
    @maKhuVuc = 'KV001', 
    @mauSac = N'Tím', 
    @hangXe = N'Suzuki', 
    @loaiXe = 0;
go
EXEC InsertPhuongTien 
    @soXe = '29B12345', 
    @tenDangNhap = '0223456789', 
    @maKhuVuc = 'KV001', 
    @mauSac = N'Đen', 
    @hangXe = N'VinFast', 
    @loaiXe = 0;

go
EXEC InsertPhuongTien 
    @soXe = '29B67890', 
    @tenDangNhap = '0912345678', 
    @maKhuVuc = 'KV001', 
    @mauSac = N'Trắng', 
    @hangXe = N'Honda', 
    @loaiXe = 0;
go

EXEC InsertPhuongTien 
    @soXe = '29C12345', 
    @tenDangNhap = '0123456789', 
    @maKhuVuc = 'KV002', 
    @mauSac = N'Cam', 
    @hangXe = N'Suzuki', 
    @loaiXe = 1;
go

EXEC InsertPhuongTien 
    @soXe = '29C67890', 
    @tenDangNhap = '0876543210', 
    @maKhuVuc = 'KV003', 
    @mauSac = N'Vàng', 
    @hangXe = N'Toyota', 
    @loaiXe = 2;
go

EXEC InsertPhuongTien 
    @soXe = '30G12345', 
    @tenDangNhap = '0912345678', 
    @maKhuVuc = 'KV001', 
    @mauSac = N'Xanh', 
    @hangXe = N'Yamaha', 
    @loaiXe = 0;
go
EXEC InsertPhuongTien 
    @soXe = '30G67890', 
    @tenDangNhap = '0987654321', 
    @maKhuVuc = 'KV002', 
    @mauSac = N'Tím', 
    @hangXe = N'VinFast', 
    @loaiXe = 1;

go
INSERT INTO nhanVien (maNV, maKhuVuc, hoTen, sdt, email, chucVu, trangThai) VALUES
('NV1', NULL, N'Nguyễn Văn A', '0912345678', 'nguyenA@gmail.com', 0, 1)

INSERT INTO taiKhoanNhanVien (tenDangNhap, maNV, password, trangThai, email) VALUES
('NV1_Login', 'NV1', 'fd1e32201acd7413f19d6c21c07310a0', 1, 'nguyenA@gmail.com');
--username: NV1_Login pass: apas@123



