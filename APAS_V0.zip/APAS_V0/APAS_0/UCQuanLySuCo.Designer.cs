﻿namespace APAS_0
{
    partial class UCQuanLySuCo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelControl2 = new Controls.PanelControl();
            label3 = new Label();
            tbName = new TextBox();
            tbType = new TextBox();
            tbColor = new TextBox();
            tbEmail = new TextBox();
            tbLicensePlate = new TextBox();
            tbSdt = new TextBox();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            buttons3 = new Controls.Buttons();
            buttons2 = new Controls.Buttons();
            buttons1 = new Controls.Buttons();
            panelControl2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panelControl2
            // 
            panelControl2.BackColor = Color.FromArgb(69, 197, 149);
            panelControl2.BorderRadius = 50;
            panelControl2.Controls.Add(label3);
            panelControl2.Controls.Add(tbName);
            panelControl2.Controls.Add(tbType);
            panelControl2.Controls.Add(tbColor);
            panelControl2.Controls.Add(tbEmail);
            panelControl2.Controls.Add(tbLicensePlate);
            panelControl2.Controls.Add(tbSdt);
            panelControl2.Controls.Add(label4);
            panelControl2.Controls.Add(label6);
            panelControl2.Controls.Add(label7);
            panelControl2.Controls.Add(label8);
            panelControl2.Controls.Add(label9);
            panelControl2.Controls.Add(label10);
            panelControl2.Location = new Point(19, 97);
            panelControl2.Name = "panelControl2";
            panelControl2.Size = new Size(344, 460);
            panelControl2.TabIndex = 37;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(110, 27);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 30;
            label3.Text = "Thông tin";
            // 
            // tbName
            // 
            tbName.Location = new Point(126, 71);
            tbName.Name = "tbName";
            tbName.Size = new Size(204, 23);
            tbName.TabIndex = 1;
            // 
            // tbType
            // 
            tbType.Location = new Point(126, 191);
            tbType.Name = "tbType";
            tbType.Size = new Size(204, 23);
            tbType.TabIndex = 4;
            // 
            // tbColor
            // 
            tbColor.Location = new Point(126, 231);
            tbColor.Name = "tbColor";
            tbColor.Size = new Size(204, 23);
            tbColor.TabIndex = 5;
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(126, 151);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(204, 23);
            tbEmail.TabIndex = 3;
            // 
            // tbLicensePlate
            // 
            tbLicensePlate.Location = new Point(126, 275);
            tbLicensePlate.Multiline = true;
            tbLicensePlate.Name = "tbLicensePlate";
            tbLicensePlate.Size = new Size(204, 152);
            tbLicensePlate.TabIndex = 6;
            // 
            // tbSdt
            // 
            tbSdt.Location = new Point(126, 111);
            tbSdt.Name = "tbSdt";
            tbSdt.Size = new Size(204, 23);
            tbSdt.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F);
            label4.Location = new Point(59, 75);
            label4.Name = "label4";
            label4.Size = new Size(58, 15);
            label4.TabIndex = 12;
            label4.Text = "Thời gian";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9F);
            label6.Location = new Point(3, 115);
            label6.Name = "label6";
            label6.Size = new Size(114, 15);
            label6.TabIndex = 13;
            label6.Text = "Đối tượng liên quan";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9F);
            label7.Location = new Point(60, 155);
            label7.Name = "label7";
            label7.Size = new Size(57, 15);
            label7.TabIndex = 14;
            label7.Text = "Địa điểm";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F);
            label8.Location = new Point(77, 195);
            label8.Name = "label8";
            label8.Size = new Size(40, 15);
            label8.TabIndex = 15;
            label8.Text = "ZONE";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9F);
            label9.Location = new Point(55, 235);
            label9.Name = "label9";
            label9.Size = new Size(62, 15);
            label9.TabIndex = 16;
            label9.Text = "Tình trạng";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 9F);
            label10.Location = new Point(68, 275);
            label10.Name = "label10";
            label10.Size = new Size(49, 15);
            label10.TabIndex = 17;
            label10.Text = "Ghi chú";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(380, 10);
            label1.Name = "label1";
            label1.Size = new Size(190, 25);
            label1.TabIndex = 38;
            label1.Text = "QUẢN LÝ SỰ CỐ";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(178, 210, 182);
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(370, 97);
            panel1.Name = "panel1";
            panel1.Size = new Size(577, 460);
            panel1.TabIndex = 39;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(10, 11);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(561, 435);
            dataGridView1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(178, 210, 182);
            label2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(380, 89);
            label2.Name = "label2";
            label2.Size = new Size(121, 16);
            label2.TabIndex = 40;
            label2.Text = "Danh sách sự cố";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(380, 63);
            label5.Name = "label5";
            label5.Size = new Size(70, 16);
            label5.TabIndex = 41;
            label5.Text = "Tìm kiếm";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(456, 61);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(161, 23);
            textBox1.TabIndex = 42;
            // 
            // buttons3
            // 
            buttons3.BackColor = Color.FromArgb(255, 75, 8);
            buttons3.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons3.BorderColor = Color.PaleVioletRed;
            buttons3.BorderColor1 = Color.PaleVioletRed;
            buttons3.BorderRadius = 20;
            buttons3.BorderRadius1 = 20;
            buttons3.BorderSize = 0;
            buttons3.BorderSize1 = 0;
            buttons3.FlatAppearance.BorderSize = 0;
            buttons3.FlatStyle = FlatStyle.Flat;
            buttons3.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons3.ForeColor = Color.White;
            buttons3.Location = new Point(839, 51);
            buttons3.Name = "buttons3";
            buttons3.Size = new Size(102, 40);
            buttons3.TabIndex = 46;
            buttons3.Text = "Xuất file";
            buttons3.TextColor = Color.White;
            buttons3.UseVisualStyleBackColor = false;
            // 
            // buttons2
            // 
            buttons2.BackColor = Color.FromArgb(255, 75, 8);
            buttons2.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons2.BorderColor = Color.PaleVioletRed;
            buttons2.BorderColor1 = Color.PaleVioletRed;
            buttons2.BorderRadius = 20;
            buttons2.BorderRadius1 = 20;
            buttons2.BorderSize = 0;
            buttons2.BorderSize1 = 0;
            buttons2.FlatAppearance.BorderSize = 0;
            buttons2.FlatStyle = FlatStyle.Flat;
            buttons2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons2.ForeColor = Color.White;
            buttons2.Location = new Point(731, 51);
            buttons2.Name = "buttons2";
            buttons2.Size = new Size(102, 40);
            buttons2.TabIndex = 45;
            buttons2.Text = "Xem tình trạng bãi";
            buttons2.TextColor = Color.White;
            buttons2.UseVisualStyleBackColor = false;
            // 
            // buttons1
            // 
            buttons1.BackColor = Color.FromArgb(255, 75, 8);
            buttons1.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons1.BorderColor = Color.PaleVioletRed;
            buttons1.BorderColor1 = Color.PaleVioletRed;
            buttons1.BorderRadius = 20;
            buttons1.BorderRadius1 = 20;
            buttons1.BorderSize = 0;
            buttons1.BorderSize1 = 0;
            buttons1.FlatAppearance.BorderSize = 0;
            buttons1.FlatStyle = FlatStyle.Flat;
            buttons1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons1.ForeColor = Color.White;
            buttons1.Location = new Point(623, 51);
            buttons1.Name = "buttons1";
            buttons1.Size = new Size(102, 40);
            buttons1.TabIndex = 44;
            buttons1.Text = "Cập nhật";
            buttons1.TextColor = Color.White;
            buttons1.UseVisualStyleBackColor = false;
            // 
            // UCQuanLySuCo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            Controls.Add(buttons3);
            Controls.Add(buttons2);
            Controls.Add(buttons1);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Controls.Add(panelControl2);
            Name = "UCQuanLySuCo";
            Size = new Size(950, 580);
            panelControl2.ResumeLayout(false);
            panelControl2.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Controls.PanelControl panelControl2;
        private Label label3;
        private TextBox tbName;
        private TextBox tbType;
        private TextBox tbColor;
        private TextBox tbEmail;
        private TextBox tbLicensePlate;
        private TextBox tbSdt;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label1;
        private Panel panel1;
        private Label label2;
        private Label label5;
        private TextBox textBox1;
        private Controls.Buttons buttons3;
        private Controls.Buttons buttons2;
        private Controls.Buttons buttons1;
        private DataGridView dataGridView1;
    }
}
