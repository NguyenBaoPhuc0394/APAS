﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DTO
{
    public class PhuongTien
    {
        private string maPT;
        private string maKH;
        private string bienSoXe;
        private string mauPT;
        private bool xeDien;
        private string hangPT;

        public string MaPT { get => maPT; set => maPT = value; }
        public string MaKH { get => maKH; set => maKH = value; }
        public string BienSoXe { get => bienSoXe; set => bienSoXe = value; }
        public string MauPT { get => mauPT; set => mauPT = value; }
        public string HangPT { get => hangPT; set => hangPT = value; }
        public bool XeDien { get => xeDien; set => xeDien = value; }

        public PhuongTien(string maPT, string maKH, string bienSoXe, string mauPT, string hangPT, bool xeDien)
        {
            MaPT = maPT;
            MaKH = maKH;
            BienSoXe = bienSoXe;
            MauPT = mauPT;
            XeDien = xeDien;
            HangPT = hangPT;
        }

        public PhuongTien(DataRow row)
        {
            MaPT = row["maPT"].ToString();
            MaKH = row["maKH"].ToString();
            BienSoXe = row["bienSoXe"].ToString();
            MauPT = row["mauPT"].ToString();
            XeDien = Convert.ToBoolean(row["xeDien"]);
            HangPT = row["hangPT"].ToString();
        }
    }
}
