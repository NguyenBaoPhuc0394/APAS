﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DTO
{
    public class KhachHang
    {
        private string maKH;
        private string hoTen;
        private string email;
        private string diachi;
        private string sdt;

        public string MaKH { get => maKH; set => maKH = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public string Email { get => email; set => email = value; }
        public string Diachi { get => diachi; set => diachi = value; }
        public string Sdt { get => sdt; set => sdt = value; }

        public KhachHang(string maKH, string hoTen, string email, string diachi, string sdt)
        {
            MaKH = maKH;
            HoTen = hoTen;
            Email = email;
            Diachi = diachi;
            Sdt = sdt;
        }

        public KhachHang(DataRow row)
        {
            MaKH = row["maKH"].ToString();
            HoTen = row["hoTen"].ToString();
            Email = row["email"].ToString();
            Diachi = row["diachi"].ToString();
            Sdt = row["sdt"].ToString();
        }
    }
}
