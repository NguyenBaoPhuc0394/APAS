﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DTO
{
    public class DichVu
    {
        private string maDV;
        private string maPT;
        private string maNV;
        private DateTime ngayDangKy;
        private DateTime ngayHetHan;
        private string hinhAnh;
        private bool conThoiHan;

        public string MaDV { get => maDV; set => maDV = value; }
        public string MaPT { get => maPT; set => maPT = value; }
        public string MaNV { get => maNV; set => maNV = value; }
        public DateTime NgayDangKy { get => ngayDangKy; set => ngayDangKy = value; }
        public DateTime NgayHetHan { get => ngayHetHan; set => ngayHetHan = value; }
        public string HinhAnh { get => hinhAnh; set => hinhAnh = value; }
        public bool ConThoiHan { get => conThoiHan; set => conThoiHan = value; }

        public DichVu(string maDV, string maPT, string maNV, DateTime ngayDangKy, DateTime ngayHetHan, string hinhAnh, bool conThoiHan)
        {
            MaDV = maDV;
            MaPT = maPT;
            MaNV = maNV;
            NgayDangKy = ngayDangKy;
            NgayHetHan = ngayHetHan;
            HinhAnh = hinhAnh;
            ConThoiHan = conThoiHan;
        }

        public DichVu(DataRow row)
        {
            MaDV = row["maDV"].ToString();
            MaPT = row["maPT"].ToString();
            MaNV = row["maNV"].ToString();
            NgayDangKy = Convert.ToDateTime(row["ngayDangKy"]);
            NgayHetHan = Convert.ToDateTime(row["ngayHetHan"]);
            HinhAnh = row["hinhAnh"].ToString();
            ConThoiHan = Convert.ToBoolean(row["conThoiHan"]);
        }


    }
}
