﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DTO
{
    public class NhanVien
    {
        private string maNV;
        private string tenNV;

        public string MaNV { get => maNV; set => maNV = value; }
        public string TenNV { get => tenNV; set => tenNV = value; }

        public NhanVien() { }   

        public NhanVien(string maNV, string tenNV)
        {
            MaNV = maNV;
            TenNV = tenNV;
        }

        public NhanVien(DataRow row)
        {
            MaNV = row["maNV"].ToString();
            TenNV = row["tenNV"].ToString();
        }
    }
}
