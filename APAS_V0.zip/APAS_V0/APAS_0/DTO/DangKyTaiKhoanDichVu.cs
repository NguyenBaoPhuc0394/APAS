﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DTO
{
    public class DangKyTaiKhoanDichVu
    {
        private string maYeuCau;
        private string hoTen;
        private string email;
        private string sdt;
        private string diachi;
        private string bienSoXM;
        private string mauSacXM;
        private string hangXM;
        private string nhienLieuXM;
        private string bienSoOT;
        private string mauSacOT;
        private string hangOT;
        private string nhienLieuOT;
        private int guiXeDap;
        private int tinhTrang;

        public string MaYeuCau { get => maYeuCau; set => maYeuCau = value; }
        public string HoTen { get => hoTen; set => hoTen = value; }
        public string Email { get => email; set => email = value; }
        public string Sdt { get => sdt; set => sdt = value; }
        public string Diachi { get => diachi; set => diachi = value; }
        public string BienSoXM { get => bienSoXM; set => bienSoXM = value; }
        public string MauSacXM { get => mauSacXM; set => mauSacXM = value; }
        public string HangXM { get => hangXM; set => hangXM = value; }
        public string NhienLieuXM { get => nhienLieuXM; set => nhienLieuXM = value; }
        public string BienSoOT { get => bienSoOT; set => bienSoOT = value; }
        public string MauSacOT { get => mauSacOT; set => mauSacOT = value; }
        public string HangOT { get => hangOT; set => hangOT = value; }
        public string NhienLieuOT { get => nhienLieuOT; set => nhienLieuOT = value; }
        public int GuiXeDap { get => guiXeDap; set => guiXeDap = value; }
        public int TinhTrang { get => tinhTrang; set => tinhTrang = value; }

        public DangKyTaiKhoanDichVu(string maYeuCau, string hoTen, string email, string sdt, string diachi, string bienSoXM, string mauSacXM, string hangXM, string nhienLieuXM, string bienSoOT, string mauSacOT, string hangOT, string nhienLieuOT, int guiXeDap, int tinhTrang)
        {
            MaYeuCau = maYeuCau;
            HoTen = hoTen;
            Email = email;
            Sdt = sdt;
            Diachi = diachi;
            BienSoXM = bienSoXM;
            MauSacXM = mauSacXM;
            HangXM = hangXM;
            NhienLieuXM = nhienLieuXM;
            BienSoOT = bienSoOT;
            MauSacOT = mauSacOT;
            HangOT = hangOT;
            NhienLieuOT = nhienLieuOT;
            GuiXeDap = guiXeDap;
            TinhTrang = tinhTrang;
        }

        public DangKyTaiKhoanDichVu(DataRow row)
        {
            MaYeuCau = row["maYeuCau"].ToString();
            HoTen = row["hoTen"].ToString();
            Email = row["email"].ToString();
            Sdt = row["sdt"].ToString();
            Diachi = row["diachi"].ToString();
            BienSoXM = row["bienSoXM"].ToString();
            MauSacXM = row["mauSacXM"].ToString();
            HangXM = row["hangXM"].ToString();
            NhienLieuXM = row["nhienLieuXM"].ToString();
            BienSoOT = row["bienSoOT"].ToString();
            MauSacOT = row["mauSacOT"].ToString();
            HangOT = row["hangOT"].ToString();
            NhienLieuOT = row["nhienLieuOT"].ToString();
            GuiXeDap = Convert.ToInt32(row["guiXeDap"].ToString());
            TinhTrang = Convert.ToInt32(row["tinhTrang"].ToString());
        }
    }
}
