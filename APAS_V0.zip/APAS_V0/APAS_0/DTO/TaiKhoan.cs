﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DTO
{
    public class TaiKhoan
    {
        private string tenTaiKhoan;
        private string matKhau;
        private string maNV;

        public string TenTaiKhoan { get => tenTaiKhoan; set => tenTaiKhoan = value; }
        public string MatKhau { get => matKhau; set => matKhau = value; }
        public string MaNV { get => maNV; set => maNV = value; }

        public TaiKhoan(string tenTaiKhoan, string matKhau, string maNV)
        {
            TenTaiKhoan = tenTaiKhoan;
            MatKhau = matKhau;
            MaNV = maNV;
        }

        public TaiKhoan(DataRow row) {
            TenTaiKhoan = row["tenTaiKhoan"].ToString();
            MatKhau = row["matKhau"].ToString();
            MaNV = row["maNV"].ToString();
        }
    }
}
