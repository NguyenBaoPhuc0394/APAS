﻿using System.Net;
using System.Net.Mail;

namespace APAS_0
{
    public class EmailSender
    {
        private static readonly SmtpClient client = new SmtpClient("smtp.gmail.com", 587)
        {
            Credentials = new NetworkCredential("apascontacting@gmail.com", "qtokpuifhzytuank"),
            EnableSsl = true
        };

        public EmailSender(){}

        public static bool responseRegister_duplicateEmail(string desEmail)
        {
           
            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("your_email@gmail.com"),
                Subject = "Phản hồi đăng ký dịch vụ gửi xe APAS",
                Body = "Chào bạn, \n Email mà bạn đăng ký đã có trên hệ thông, vui lòng hãy đăng ký bằng một email khác. Trường hợp bạn quên mật khẩu hãy chọn phần quên mật khẩu trong giao diện đăng nhập của ứng dụng.\n" +
                "Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của chúng tôi.",
                IsBodyHtml = false
            };

            mailMessage.To.Add(desEmail);
            client.Send(mailMessage);
            return true;
        }

        public static bool responseRegister_duplicatePhonenumber(string desEmail, string phoneNumber)
        {

            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("your_email@gmail.com"),
                Subject = "Phản hồi đăng ký dịch vụ gửi xe APAS",
                Body = "Chào bạn, \n Số điện thoại: "+ phoneNumber +" mà bạn đăng ký đã có trên hệ thông, vui lòng hãy đăng ký bằng một số điện thoại khác.\n" +
                "Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của chúng tôi.",
                IsBodyHtml = false
            };

            mailMessage.To.Add(desEmail);
            client.Send(mailMessage);
            return true;
        }
        public static bool responseRegister_duplicateVehicle(string desEmail, string number)
        {

            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("your_email@gmail.com"),
                Subject = "Phản hồi đăng ký dịch vụ gửi xe APAS",
                Body = "Chào bạn, \n phương tiện mang biển số: " + number + " mà bạn đăng ký đã có trên hệ thông, vui lòng hãy thực hiện lại yêu cầu đăng ký khác, trường hợp không có phương tiện bạn hãy để trông các trường phương tiện trong biểu mẫu đăng ký.\n" +
                "Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của chúng tôi.",
                IsBodyHtml = false
            };

            mailMessage.To.Add(desEmail);
            client.Send(mailMessage);
            return true;
        }

        public static bool responseRegister_runOutOfSpace(string desEmail)
        {

            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("your_email@gmail.com"),
                Subject = "Phản hồi đăng ký dịch vụ gửi xe APAS",
                Body = "Chào bạn, hiện tại chúng tôi đã hết chỗ đỗ xe. Vui lòng đăng ký lại vào dịp gần nhất. \n" +
                "Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của chúng tôi.",
                IsBodyHtml = false
            };

            mailMessage.To.Add(desEmail);
            client.Send(mailMessage);
            return true;
        }

        public static bool responseRegister_success(string desEmail)
        {
            MailMessage mailMessage = new MailMessage
            {
                From = new MailAddress("your_email@gmail.com"),
                Subject = "Phản hồi đăng ký dịch vụ gửi xe APAS",
                Body = "Chào bạn, Chúc mừng bạn đã đăng ký thành công dịch vụ gửi xe APAS \n Tài khoản và mật khẩu đều là số điện thoại mà bạn đăng ký." +
                "Vui lòng không chia sẻ cho bất kỳ ai và thực hiện đổi mật khẩu ngay lần đầu đăng nhập\n"+
               "Cảm ơn bạn đã tin tưởng sử dụng dịch vụ của chúng tôi.",
                IsBodyHtml = false
            };

            mailMessage.To.Add(desEmail);
            client.Send(mailMessage);
            return true;
        }
    }
        
    
}
