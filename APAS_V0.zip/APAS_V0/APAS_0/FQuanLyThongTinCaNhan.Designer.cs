﻿namespace APAS_0
{
    partial class FQuanLyThongTinCaNhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttons3 = new Controls.Buttons();
            buttons2 = new Controls.Buttons();
            buttons1 = new Controls.Buttons();
            pictureBox1 = new PictureBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panelControl1 = new Controls.PanelControl();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelControl1.SuspendLayout();
            SuspendLayout();
            // 
            // buttons3
            // 
            buttons3.BackColor = Color.FromArgb(255, 128, 0);
            buttons3.BackgroundColor = Color.FromArgb(255, 128, 0);
            buttons3.BorderColor = Color.PaleVioletRed;
            buttons3.BorderRadius = 15;
            buttons3.BorderSize = 0;
            buttons3.FlatAppearance.BorderSize = 0;
            buttons3.FlatStyle = FlatStyle.Flat;
            buttons3.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            buttons3.ForeColor = Color.White;
            buttons3.Location = new Point(16, 250);
            buttons3.Name = "buttons3";
            buttons3.Size = new Size(133, 40);
            buttons3.TabIndex = 4;
            buttons3.Text = "Đổi mật khẩu";
            buttons3.TextColor = Color.White;
            buttons3.UseVisualStyleBackColor = false;
            // 
            // buttons2
            // 
            buttons2.BackColor = Color.BlueViolet;
            buttons2.BackgroundColor = Color.BlueViolet;
            buttons2.BorderColor = Color.PaleVioletRed;
            buttons2.BorderRadius = 15;
            buttons2.BorderSize = 0;
            buttons2.FlatAppearance.BorderSize = 0;
            buttons2.FlatStyle = FlatStyle.Flat;
            buttons2.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            buttons2.ForeColor = Color.White;
            buttons2.Location = new Point(172, 250);
            buttons2.Name = "buttons2";
            buttons2.Size = new Size(108, 40);
            buttons2.TabIndex = 5;
            buttons2.Text = "Sửa";
            buttons2.TextColor = Color.White;
            buttons2.UseVisualStyleBackColor = false;
            // 
            // buttons1
            // 
            buttons1.BackColor = Color.FromArgb(0, 192, 0);
            buttons1.BackgroundColor = Color.FromArgb(0, 192, 0);
            buttons1.BorderColor = Color.PaleVioletRed;
            buttons1.BorderRadius = 15;
            buttons1.BorderSize = 0;
            buttons1.FlatAppearance.BorderSize = 0;
            buttons1.FlatStyle = FlatStyle.Flat;
            buttons1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            buttons1.ForeColor = Color.White;
            buttons1.Location = new Point(302, 250);
            buttons1.Name = "buttons1";
            buttons1.Size = new Size(108, 40);
            buttons1.TabIndex = 6;
            buttons1.Text = "Lưu";
            buttons1.TextColor = Color.White;
            buttons1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Dọc___màu;
            pictureBox1.Location = new Point(3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(70, 70);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(152, 195);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(209, 23);
            textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(152, 160);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(209, 23);
            textBox4.TabIndex = 2;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(152, 125);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(209, 23);
            textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(152, 90);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(209, 23);
            textBox1.TabIndex = 0;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            label5.Location = new Point(34, 201);
            label5.Name = "label5";
            label5.Size = new Size(58, 17);
            label5.TabIndex = 4;
            label5.Text = "Lĩnh vực";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            label4.Location = new Point(34, 166);
            label4.Name = "label4";
            label4.Size = new Size(90, 17);
            label4.TabIndex = 3;
            label4.Text = "Tên tài khoản";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold);
            label3.Location = new Point(34, 131);
            label3.Name = "label3";
            label3.Size = new Size(91, 17);
            label3.TabIndex = 2;
            label3.Text = "Mã nhân viên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(34, 96);
            label2.Name = "label2";
            label2.Size = new Size(68, 17);
            label2.TabIndex = 1;
            label2.Text = "Họ và tên";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(112, 31);
            label1.Name = "label1";
            label1.Size = new Size(298, 25);
            label1.TabIndex = 0;
            label1.Text = "QUẢN LÝ THÔNG TIN CÁ NHÂN";
            // 
            // panelControl1
            // 
            panelControl1.BackColor = Color.FromArgb(50, 144, 176);
            panelControl1.BorderRadius = 40;
            panelControl1.Controls.Add(buttons3);
            panelControl1.Controls.Add(pictureBox1);
            panelControl1.Controls.Add(label5);
            panelControl1.Controls.Add(buttons2);
            panelControl1.Controls.Add(textBox1);
            panelControl1.Controls.Add(buttons1);
            panelControl1.Controls.Add(label4);
            panelControl1.Controls.Add(textBox2);
            panelControl1.Controls.Add(label1);
            panelControl1.Controls.Add(label3);
            panelControl1.Controls.Add(textBox3);
            panelControl1.Controls.Add(textBox4);
            panelControl1.Controls.Add(label2);
            panelControl1.Location = new Point(62, 45);
            panelControl1.Name = "panelControl1";
            panelControl1.Padding = new Padding(10);
            panelControl1.Size = new Size(438, 311);
            panelControl1.TabIndex = 1;
            // 
            // FQuanLyThongTinCaNhan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Silver;
            ClientSize = new Size(539, 401);
            Controls.Add(panelControl1);
            Name = "FQuanLyThongTinCaNhan";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FQuanLyThongTinCaNhan";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelControl1.ResumeLayout(false);
            panelControl1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox4;
        private PictureBox pictureBox1;
        private Controls.Buttons buttons1;
        private Controls.Buttons buttons3;
        private Controls.Buttons buttons2;
        private Controls.PanelControl panelControl1;
    }
}