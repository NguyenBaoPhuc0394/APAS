﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APAS_0
{
    public partial class FPhanHoiKhachHang : Form
    {
        private FMain form;
        public FPhanHoiKhachHang(FMain f)
        {
            InitializeComponent();
            this.form = f;
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            radioButton5 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            panelControl1 = new Controls.PanelControl();
            responseButton = new Controls.Buttons();
            panelControl1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 18);
            label1.Name = "label1";
            label1.Size = new Size(249, 24);
            label1.TabIndex = 0;
            label1.Text = "Phản hồi cho khách hàng";
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Font = new Font("Microsoft Sans Serif", 9.75F);
            radioButton5.Location = new Point(12, 202);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(107, 20);
            radioButton5.TabIndex = 4;
            radioButton5.TabStop = true;
            radioButton5.Text = "Hết chỗ đỗ xe";
            radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Font = new Font("Microsoft Sans Serif", 9.75F);
            radioButton4.Location = new Point(12, 167);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(154, 20);
            radioButton4.TabIndex = 3;
            radioButton4.TabStop = true;
            radioButton4.Text = "Trùng lập biển số ô tô";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Microsoft Sans Serif", 9.75F);
            radioButton3.Location = new Point(12, 131);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(175, 20);
            radioButton3.TabIndex = 2;
            radioButton3.TabStop = true;
            radioButton3.Text = "Trùng lập biển số xe máy";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Microsoft Sans Serif", 9.75F);
            radioButton2.Location = new Point(12, 93);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(118, 20);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Trùng lập email";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Microsoft Sans Serif", 9.75F);
            radioButton1.Location = new Point(12, 57);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(161, 20);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Trùng lập số điện thoại";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // panelControl1
            // 
            panelControl1.BackColor = Color.FromArgb(164, 194, 211);
            panelControl1.BorderRadius = 50;
            panelControl1.Controls.Add(responseButton);
            panelControl1.Controls.Add(radioButton5);
            panelControl1.Controls.Add(label1);
            panelControl1.Controls.Add(radioButton4);
            panelControl1.Controls.Add(radioButton1);
            panelControl1.Controls.Add(radioButton3);
            panelControl1.Controls.Add(radioButton2);
            panelControl1.Location = new Point(45, 43);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(272, 308);
            panelControl1.TabIndex = 7;
            // 
            // responseButton
            // 
            responseButton.BackColor = Color.FromArgb(255, 75, 8);
            responseButton.BackgroundColor = Color.FromArgb(255, 75, 8);
            responseButton.BorderColor = Color.PaleVioletRed;
            responseButton.BorderColor1 = Color.PaleVioletRed;
            responseButton.BorderRadius = 20;
            responseButton.BorderRadius1 = 20;
            responseButton.BorderSize = 0;
            responseButton.BorderSize1 = 0;
            responseButton.FlatAppearance.BorderSize = 0;
            responseButton.FlatStyle = FlatStyle.Flat;
            responseButton.ForeColor = Color.White;
            responseButton.Location = new Point(61, 248);
            responseButton.Name = "responseButton";
            responseButton.Size = new Size(150, 40);
            responseButton.TabIndex = 5;
            responseButton.Text = "Gửi phản hồi";
            responseButton.TextColor = Color.White;
            responseButton.UseVisualStyleBackColor = false;
            // 
            // Form2
            // 
            ClientSize = new Size(363, 395);
            Controls.Add(panelControl1);
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            panelControl1.ResumeLayout(false);
            panelControl1.PerformLayout();
            ResumeLayout(false);
        }

        private RadioButton radioButton5;
        private Controls.PanelControl panelControl1;
        private Controls.Buttons responseButton;
        private Label label1;

        

        private void responseButton_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                //if (EmailSender.responseRegister_duplicatePhonenumber(form1.getEmail(), form1.getPhoneNumber()))
                //{
                //    MessageBox.Show("Phản hồi được gửi thành công");
                //}
            }
            else if (radioButton2.Checked)
            {
                //if (EmailSender.responseRegister_duplicateEmail(form1.getEmail()))
                //{
                //    MessageBox.Show("Phản hồi được gửi thành công");
                //}
            }
            //else if (radioButton3.Checked)
            //{
            //    if (EmailSender.responseRegister_duplicateVehicle(form1.getEmail(), form1.getMotorNumber()))
            //    {
            //        MessageBox.Show("Phản hồi được gửi thành công");
            //    }
            //}
            else if (radioButton5.Checked)
            {
                //if (EmailSender.responseRegister_runOutOfSpace(form1.getEmail()))
                //{
                //    MessageBox.Show("Phản hồi được gửi thành công");
                //}
            }
            //else
            //{
            //    if(EmailSender.responseRegister_duplicateVehicle(form1.getEmail(), form1.getCarNumber()))
            //    {
            //        MessageBox.Show("Phản hồi được gửi thành công");
            //    }
            //}
            //SqlConnector.UpdateRegisterRequestStatus(form1.getRequestID());

            //form1.reloadForm();

            this.Close();
            
        }
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
    }
}
