﻿namespace APAS_0
{
    partial class UCThanhToan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelControl2 = new Controls.PanelControl();
            comboBox1 = new ComboBox();
            label3 = new Label();
            tbName = new TextBox();
            tbType = new TextBox();
            tbEmail = new TextBox();
            tbSdt = new TextBox();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            panelControl1 = new Controls.PanelControl();
            dateTimePicker1 = new DateTimePicker();
            label2 = new Label();
            label1 = new Label();
            buttons3 = new Controls.Buttons();
            textBox4 = new TextBox();
            label11 = new Label();
            label12 = new Label();
            panel1 = new Panel();
            dataGridView1 = new DataGridView();
            label13 = new Label();
            buttons1 = new Controls.Buttons();
            buttons2 = new Controls.Buttons();
            panelControl2.SuspendLayout();
            panelControl1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panelControl2
            // 
            panelControl2.BackColor = Color.FromArgb(69, 197, 149);
            panelControl2.BorderRadius = 50;
            panelControl2.Controls.Add(comboBox1);
            panelControl2.Controls.Add(label3);
            panelControl2.Controls.Add(tbName);
            panelControl2.Controls.Add(tbType);
            panelControl2.Controls.Add(tbEmail);
            panelControl2.Controls.Add(tbSdt);
            panelControl2.Controls.Add(label4);
            panelControl2.Controls.Add(label6);
            panelControl2.Controls.Add(label7);
            panelControl2.Controls.Add(label8);
            panelControl2.Controls.Add(label9);
            panelControl2.Location = new Point(14, 104);
            panelControl2.Name = "panelControl2";
            panelControl2.Size = new Size(344, 280);
            panelControl2.TabIndex = 39;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(126, 231);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(204, 23);
            comboBox1.TabIndex = 31;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(110, 27);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 30;
            label3.Text = "Thông tin";
            // 
            // tbName
            // 
            tbName.Location = new Point(126, 71);
            tbName.Name = "tbName";
            tbName.Size = new Size(204, 23);
            tbName.TabIndex = 1;
            // 
            // tbType
            // 
            tbType.Location = new Point(126, 191);
            tbType.Name = "tbType";
            tbType.Size = new Size(204, 23);
            tbType.TabIndex = 4;
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(126, 151);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(204, 23);
            tbEmail.TabIndex = 3;
            // 
            // tbSdt
            // 
            tbSdt.Location = new Point(126, 111);
            tbSdt.Name = "tbSdt";
            tbSdt.Size = new Size(204, 23);
            tbSdt.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F);
            label4.Location = new Point(37, 75);
            label4.Name = "label4";
            label4.Size = new Size(86, 15);
            label4.TabIndex = 12;
            label4.Text = "Mã thanh toán";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9F);
            label6.Location = new Point(31, 115);
            label6.Name = "label6";
            label6.Size = new Size(92, 15);
            label6.TabIndex = 13;
            label6.Text = "Mã khách hàng";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9F);
            label7.Location = new Point(28, 155);
            label7.Name = "label7";
            label7.Size = new Size(95, 15);
            label7.TabIndex = 14;
            label7.Text = "Tên khách hàng";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F);
            label8.Location = new Point(61, 195);
            label8.Name = "label8";
            label8.Size = new Size(62, 15);
            label8.TabIndex = 15;
            label8.Text = "Tình trạng";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9F);
            label9.Location = new Point(3, 235);
            label9.Name = "label9";
            label9.Size = new Size(120, 15);
            label9.TabIndex = 16;
            label9.Text = "Hình thức thanh toán";
            // 
            // panelControl1
            // 
            panelControl1.BorderRadius = 50;
            panelControl1.Controls.Add(dateTimePicker1);
            panelControl1.Controls.Add(label2);
            panelControl1.Controls.Add(label1);
            panelControl1.Location = new Point(14, 456);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(344, 104);
            panelControl1.TabIndex = 40;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(126, 31);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(204, 23);
            dateTimePicker1.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 9.75F);
            label2.Location = new Point(226, 70);
            label2.Name = "label2";
            label2.Size = new Size(48, 16);
            label2.TabIndex = 1;
            label2.Text = "Số tiền";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(37, 70);
            label1.Name = "label1";
            label1.Size = new Size(86, 18);
            label1.TabIndex = 0;
            label1.Text = "Thành tiền";
            // 
            // buttons3
            // 
            buttons3.BackColor = Color.FromArgb(255, 75, 8);
            buttons3.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons3.BorderColor = Color.PaleVioletRed;
            buttons3.BorderRadius = 20;
            buttons3.BorderSize = 0;
            buttons3.FlatAppearance.BorderSize = 0;
            buttons3.FlatStyle = FlatStyle.Flat;
            buttons3.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons3.ForeColor = Color.White;
            buttons3.Location = new Point(835, 53);
            buttons3.Name = "buttons3";
            buttons3.Size = new Size(102, 40);
            buttons3.TabIndex = 62;
            buttons3.Text = "Xoá";
            buttons3.TextColor = Color.White;
            buttons3.UseVisualStyleBackColor = false;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(441, 63);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(146, 23);
            textBox4.TabIndex = 61;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(365, 65);
            label11.Name = "label11";
            label11.Size = new Size(70, 16);
            label11.TabIndex = 60;
            label11.Text = "Tìm kiếm";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.FromArgb(178, 210, 182);
            label12.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(375, 91);
            label12.Name = "label12";
            label12.Size = new Size(155, 16);
            label12.TabIndex = 59;
            label12.Text = "Danh sách thanh toán";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(178, 210, 182);
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(365, 100);
            panel1.Name = "panel1";
            panel1.Size = new Size(577, 460);
            panel1.TabIndex = 58;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(10, 11);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(561, 446);
            dataGridView1.TabIndex = 0;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(381, 10);
            label13.Name = "label13";
            label13.Size = new Size(158, 25);
            label13.TabIndex = 57;
            label13.Text = "THANH TOÁN";
            // 
            // buttons1
            // 
            buttons1.BackColor = Color.FromArgb(255, 75, 8);
            buttons1.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons1.BorderColor = Color.PaleVioletRed;
            buttons1.BorderRadius = 20;
            buttons1.BorderSize = 0;
            buttons1.FlatAppearance.BorderSize = 0;
            buttons1.FlatStyle = FlatStyle.Flat;
            buttons1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons1.ForeColor = Color.White;
            buttons1.Location = new Point(727, 54);
            buttons1.Name = "buttons1";
            buttons1.Size = new Size(102, 40);
            buttons1.TabIndex = 63;
            buttons1.Text = "Sửa";
            buttons1.TextColor = Color.White;
            buttons1.UseVisualStyleBackColor = false;
            // 
            // buttons2
            // 
            buttons2.BackColor = Color.FromArgb(255, 75, 8);
            buttons2.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons2.BorderColor = Color.PaleVioletRed;
            buttons2.BorderRadius = 20;
            buttons2.BorderSize = 0;
            buttons2.FlatAppearance.BorderSize = 0;
            buttons2.FlatStyle = FlatStyle.Flat;
            buttons2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons2.ForeColor = Color.White;
            buttons2.Location = new Point(619, 54);
            buttons2.Name = "buttons2";
            buttons2.Size = new Size(102, 40);
            buttons2.TabIndex = 64;
            buttons2.Text = "Thêm";
            buttons2.TextColor = Color.White;
            buttons2.UseVisualStyleBackColor = false;
            // 
            // UCThanhToan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            Controls.Add(buttons2);
            Controls.Add(buttons1);
            Controls.Add(buttons3);
            Controls.Add(textBox4);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(panel1);
            Controls.Add(label13);
            Controls.Add(panelControl1);
            Controls.Add(panelControl2);
            Name = "UCThanhToan";
            Size = new Size(950, 580);
            panelControl2.ResumeLayout(false);
            panelControl2.PerformLayout();
            panelControl1.ResumeLayout(false);
            panelControl1.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Controls.PanelControl panelControl2;
        private Label label3;
        private TextBox tbName;
        private TextBox tbType;
        private TextBox tbEmail;
        private TextBox tbSdt;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private ComboBox comboBox1;
        private Controls.PanelControl panelControl1;
        private DateTimePicker dateTimePicker1;
        private Label label2;
        private Label label1;
        private Controls.Buttons buttons3;
        private TextBox textBox4;
        private Label label11;
        private Label label12;
        private Panel panel1;
        private DataGridView dataGridView1;
        private Label label13;
        private Controls.Buttons buttons1;
        private Controls.Buttons buttons2;
    }
}
