﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Sheets.v4;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using APAS_0.DTO;
using System.Data.SqlClient;
using APAS_0.DAL;
using System.Net;
using APAS_0.Controls;

namespace APAS_0
{
    public partial class FMain : Form
    {
        private NhanVien nhanvien;
        public NhanVien Nhanvien { get => nhanvien; set => nhanvien = value; }
        public FMain(NhanVien nv)
        {
            InitializeComponent();
            Nhanvien = nv;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            pnlShowUC.Controls.Clear();
            UCDangKyDichVu uc = new UCDangKyDichVu(Nhanvien);
            pnlShowUC.Controls.Add(uc);
        }

        private void BtnServices_Click(object sender, EventArgs e)
        {
            pnlShowUC.Controls.Clear();
            UCQuanLyDichVu uc = new UCQuanLyDichVu();
            pnlShowUC.Controls.Add(uc);
        }

        private void BtnParkingLot_Click(object sender, EventArgs e)
        {
            pnlShowUC.Controls.Clear();
            UCQuanLyBaiGiuXe uc = new UCQuanLyBaiGiuXe();
            pnlShowUC.Controls.Add(uc);
        }

        private void BtnProblem_Click(object sender, EventArgs e)
        {
            pnlShowUC.Controls.Clear();
            UCQuanLySuCo uc = new UCQuanLySuCo();
            pnlShowUC.Controls.Add(uc);
        }

        private void BtnPay_Click(object sender, EventArgs e)
        {
            pnlShowUC.Controls.Clear();
            UCThanhToan uc = new UCThanhToan();
            pnlShowUC.Controls.Add(uc);
        }

        private void BtnInfoPersonal_Click(object sender, EventArgs e)
        {
            pnlShowUC.Controls.Clear();
            UCQuanLyThongTinCaNhan uc = new UCQuanLyThongTinCaNhan();
            pnlShowUC.Controls.Add(uc);
        }

        //private void BtnNotify_Click(object sender, EventArgs e)
        //{
        //    FPhanHoiKhachHang f = new FPhanHoiKhachHang(this);
        //    f.ShowDialog();
        //}
    }
}
