﻿using System.Drawing;
using System.Windows.Forms;

namespace APAS_0
{
    partial class FLoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FLoginForm));
            panel2 = new Panel();
            tbUsername = new TextBox();
            btnLogin = new Controls.Buttons();
            btnSignUp = new Controls.Buttons();
            btnShowOrHidden = new Button();
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            llbResetPassword = new LinkLabel();
            tbPassWord = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            label5 = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(46, 177, 255);
            panel2.BackgroundImageLayout = ImageLayout.Zoom;
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(tbUsername);
            panel2.Controls.Add(btnLogin);
            panel2.Controls.Add(btnSignUp);
            panel2.Controls.Add(btnShowOrHidden);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(llbResetPassword);
            panel2.Controls.Add(tbPassWord);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(457, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(345, 416);
            panel2.TabIndex = 1;
            // 
            // tbUsername
            // 
            tbUsername.Location = new Point(72, 166);
            tbUsername.Name = "tbUsername";
            tbUsername.Size = new Size(240, 23);
            tbUsername.TabIndex = 17;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.MediumSlateBlue;
            btnLogin.BackgroundColor = Color.MediumSlateBlue;
            btnLogin.BorderColor = Color.PaleVioletRed;
            btnLogin.BorderColor1 = Color.PaleVioletRed;
            btnLogin.BorderRadius = 20;
            btnLogin.BorderRadius1 = 20;
            btnLogin.BorderSize = 0;
            btnLogin.BorderSize1 = 0;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Verdana", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(96, 322);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(167, 40);
            btnLogin.TabIndex = 16;
            btnLogin.Text = "Đăng nhập";
            btnLogin.TextColor = Color.White;
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnSignUp
            // 
            btnSignUp.BackColor = Color.MediumSlateBlue;
            btnSignUp.BackgroundColor = Color.MediumSlateBlue;
            btnSignUp.BorderColor = Color.PaleVioletRed;
            btnSignUp.BorderColor1 = Color.PaleVioletRed;
            btnSignUp.BorderRadius = 20;
            btnSignUp.BorderRadius1 = 20;
            btnSignUp.BorderSize = 0;
            btnSignUp.BorderSize1 = 0;
            btnSignUp.FlatAppearance.BorderSize = 0;
            btnSignUp.FlatStyle = FlatStyle.Flat;
            btnSignUp.Font = new Font("Verdana", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSignUp.ForeColor = Color.White;
            btnSignUp.Location = new Point(211, 6);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.Size = new Size(125, 40);
            btnSignUp.TabIndex = 15;
            btnSignUp.Text = "Đăng kí";
            btnSignUp.TextColor = Color.White;
            btnSignUp.UseVisualStyleBackColor = false;
            // 
            // btnShowOrHidden
            // 
            btnShowOrHidden.BackColor = Color.White;
            btnShowOrHidden.FlatAppearance.BorderSize = 0;
            btnShowOrHidden.FlatStyle = FlatStyle.Flat;
            btnShowOrHidden.Image = Properties.Resources.hidden;
            btnShowOrHidden.Location = new Point(278, 242);
            btnShowOrHidden.Name = "btnShowOrHidden";
            btnShowOrHidden.Size = new Size(30, 20);
            btnShowOrHidden.TabIndex = 14;
            btnShowOrHidden.UseVisualStyleBackColor = false;
            btnShowOrHidden.Click += btnShowOrHidden_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(34, 234);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(33, 31);
            pictureBox3.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox3.TabIndex = 9;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(34, 161);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(33, 32);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // llbResetPassword
            // 
            llbResetPassword.ActiveLinkColor = Color.Indigo;
            llbResetPassword.AutoSize = true;
            llbResetPassword.Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            llbResetPassword.LinkBehavior = LinkBehavior.HoverUnderline;
            llbResetPassword.LinkColor = Color.Black;
            llbResetPassword.Location = new Point(205, 289);
            llbResetPassword.Name = "llbResetPassword";
            llbResetPassword.Size = new Size(107, 16);
            llbResetPassword.TabIndex = 5;
            llbResetPassword.TabStop = true;
            llbResetPassword.Text = "Quên mật khẩu";
            llbResetPassword.LinkClicked += llbResetPassword_LinkClicked;
            // 
            // tbPassWord
            // 
            tbPassWord.Location = new Point(72, 240);
            tbPassWord.Name = "tbPassWord";
            tbPassWord.Size = new Size(240, 23);
            tbPassWord.TabIndex = 4;
            tbPassWord.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(78, 221);
            label4.Name = "label4";
            label4.Size = new Size(68, 16);
            label4.TabIndex = 3;
            label4.Text = "Mật khẩu";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(75, 147);
            label3.Name = "label3";
            label3.Size = new Size(71, 16);
            label3.TabIndex = 1;
            label3.Text = "Tài khoản";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Courier New", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(93, 83);
            label2.Name = "label2";
            label2.Size = new Size(158, 31);
            label2.TabIndex = 0;
            label2.Text = "ĐĂNG NHẬP";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(457, 416);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(75, 191);
            label1.Name = "label1";
            label1.Size = new Size(120, 13);
            label1.TabIndex = 18;
            label1.Text = "Tài khoản không hợp lệ";
            label1.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Red;
            label5.Location = new Point(78, 266);
            label5.Name = "label5";
            label5.Size = new Size(117, 13);
            label5.TabIndex = 19;
            label5.Text = "Mật khẩu không hợp lệ";
            label5.Visible = false;
            // 
            // FLoginForm
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoSize = true;
            ClientSize = new Size(800, 416);
            Controls.Add(panel2);
            Controls.Add(pictureBox2);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            MaximizeBox = false;
            Name = "FLoginForm";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ĐĂNG NHẬP";
            FormClosing += FLoginForm_FormClosing;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private TextBox tbPassWord;
        private Label label4;
        //private TextBox tbUsername;
        private Label label3;
        private Label label2;
        private LinkLabel llbResetPassword;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Controls.Buttons loginButton1;
        private Controls.Buttons loginButton2;
        private Button btnShowOrHidden;
        private Controls.Buttons btnSignUp;
        private Controls.Buttons btnLogin;
        private TextBox tbUsername;
        private Label label1;
        private Label label5;
    }
}
