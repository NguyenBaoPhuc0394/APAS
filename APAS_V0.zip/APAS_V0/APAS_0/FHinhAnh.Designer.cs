﻿namespace APAS_0
{
    partial class FHinhAnh
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            btnOK = new Button();
            btnExport = new Button();
            btnLoad = new Button();
            ptbImage = new PictureBox();
            openFileDialog = new OpenFileDialog();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbImage).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DeepSkyBlue;
            panel1.Controls.Add(btnOK);
            panel1.Controls.Add(btnExport);
            panel1.Controls.Add(btnLoad);
            panel1.Controls.Add(ptbImage);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(776, 426);
            panel1.TabIndex = 0;
            // 
            // btnOK
            // 
            btnOK.Location = new Point(23, 376);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(112, 34);
            btnOK.TabIndex = 3;
            btnOK.Text = "OK";
            btnOK.UseVisualStyleBackColor = true;
            btnOK.Click += btnOK_Click;
            // 
            // btnExport
            // 
            btnExport.Location = new Point(23, 74);
            btnExport.Name = "btnExport";
            btnExport.Size = new Size(134, 34);
            btnExport.TabIndex = 2;
            btnExport.Text = "ExportImage";
            btnExport.UseVisualStyleBackColor = true;
            btnExport.Click += btnExport_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(23, 19);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(112, 34);
            btnLoad.TabIndex = 1;
            btnLoad.Text = "LoadImage";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // ptbImage
            // 
            ptbImage.BackColor = Color.Azure;
            ptbImage.Location = new Point(180, 3);
            ptbImage.Name = "ptbImage";
            ptbImage.Size = new Size(593, 423);
            ptbImage.TabIndex = 0;
            ptbImage.TabStop = false;
            // 
            // openFileDialog
            // 
            openFileDialog.FileName = "openFileDialog1";
            openFileDialog.Multiselect = true;
            // 
            // FHinhAnh
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Name = "FHinhAnh";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hình ảnh";
            Load += FHinhAnh_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ptbImage).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox ptbImage;
        private Button btnLoad;
        private OpenFileDialog openFileDialog;
        private Button btnExport;
        private Button btnOK;
    }
}
