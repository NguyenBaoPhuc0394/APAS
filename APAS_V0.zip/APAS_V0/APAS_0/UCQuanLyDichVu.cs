﻿using APAS_0.DAL;
using APAS_0.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APAS_0
{
    public partial class UCQuanLyDichVu : UserControl
    {
        //private NhanVien nhanvien;

        //public NhanVien Nhanvien { get => nhanvien; set => nhanvien = value; }
        //public UCQuanLyDichVu(NhanVien nv)
        //{
        //    InitializeComponent();
        //    this.nhanvien = nv;
        //}

        public UCQuanLyDichVu()
        {
            InitializeComponent();
        }

        //private void UCQuanLyDichVu_Load(object sender, EventArgs e)
        //{
        //    tbStaff.Text = Nhanvien.TenNV;
        //    DataTable dt = DichVuDAL.Instance.GetDataServices();
        //    ShowList(dt);
        //}

        //private void ShowList(DataTable dt)
        //{
        //    DataTable dataTable = new DataTable();
        //    dataTable.Columns.Add("Mã dịch vụ");
        //    dataTable.Columns.Add("Họ tên");
        //    dataTable.Columns.Add("Số điện thoại");
        //    dataTable.Columns.Add("Biển số xe");
        //    dataTable.Columns.Add("Loại phương tiện");
        //    dataTable.Columns.Add("Thời gian đăng ký");
        //    dataTable.Columns.Add("Thời gian hết hạn");
        //    dataTable.Columns.Add("Hình ảnh");

        //    for (int i = 0; i < dt.Rows.Count; i++)
        //    {
        //        DataRow row = dataTable.NewRow();
        //        row["Mã dịch vụ"] = dt.Rows[i][0];
        //        row["Họ tên"] = dt.Rows[i][1];
        //        row["Số điện thoại"] = dt.Rows[i][2];
        //        row["Biển số xe"] = dt.Rows[i][3];
        //        row["Loại phương tiện"] = dt.Rows[i][4];
        //        row["Thời gian đăng ký"] = dt.Rows[i][5];
        //        row["Thời gian hết hạn"] = dt.Rows[i][6];
        //        row["Hình ảnh"] = dt.Rows[i][7];
        //        dataTable.Rows.Add(row);
        //    }

        //    dtgvTK.DataSource = dataTable;
        //}

        //private void dtgvTK_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        //{
        //    //DataGridViewRow row = dtgvTK.SelectedRows[0];
        //    int index = dtgvTK.SelectedCells[0].RowIndex;
        //    DataGridViewRow row = dtgvTK.Rows[index];
        //    string hoTen = row.Cells[1].Value.ToString() ?? "";
        //    string sdt = row.Cells[2].Value.ToString() ?? "";
        //    string ngayDK = row.Cells[5].Value.ToString() ?? "";
        //    string ngayHH = row.Cells[6].Value.ToString() ?? "";
        //    string staff = tbStaff.Text;
        //    string bsx = row.Cells[3].Value.ToString() ?? "";
        //    string hinhanh = row.Cells[7].Value.ToString() ?? "";
        //    FHinhAnh fha = new FHinhAnh(hoTen, sdt, ngayDK, ngayHH, staff, bsx, hinhanh);
        //    fha.ShowDialog();
        //    //if (fha.ShowDialog() == DialogResult.OK)
        //    //{
        //    //    lbHinhanh.Text = fha.Hinhanh;
        //    //}
        //}
    }
}
