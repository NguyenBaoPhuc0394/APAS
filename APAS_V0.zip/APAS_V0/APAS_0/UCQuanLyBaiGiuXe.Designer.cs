﻿namespace APAS_0
{
    partial class UCQuanLyBaiGiuXe
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            panelControl2 = new Controls.PanelControl();
            label3 = new Label();
            tbName = new TextBox();
            cbElec = new CheckBox();
            tbType = new TextBox();
            tbColor = new TextBox();
            tbEmail = new TextBox();
            tbLicensePlate = new TextBox();
            tbSdt = new TextBox();
            tbAddress = new TextBox();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label11 = new Label();
            label9 = new Label();
            label10 = new Label();
            tbBrand = new TextBox();
            label13 = new Label();
            panel1 = new Panel();
            dataGridView1 = new DataGridView();
            label2 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            buttons1 = new Controls.Buttons();
            buttons2 = new Controls.Buttons();
            buttons3 = new Controls.Buttons();
            panelControl2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(356, 10);
            label1.Name = "label1";
            label1.Size = new Size(238, 25);
            label1.TabIndex = 37;
            label1.Text = "QUẢN LÝ BÃI GIỮ XE";
            // 
            // panelControl2
            // 
            panelControl2.BackColor = Color.FromArgb(69, 197, 149);
            panelControl2.BorderRadius = 50;
            panelControl2.Controls.Add(label3);
            panelControl2.Controls.Add(tbName);
            panelControl2.Controls.Add(cbElec);
            panelControl2.Controls.Add(tbType);
            panelControl2.Controls.Add(tbColor);
            panelControl2.Controls.Add(tbEmail);
            panelControl2.Controls.Add(tbLicensePlate);
            panelControl2.Controls.Add(tbSdt);
            panelControl2.Controls.Add(tbAddress);
            panelControl2.Controls.Add(label4);
            panelControl2.Controls.Add(label6);
            panelControl2.Controls.Add(label7);
            panelControl2.Controls.Add(label8);
            panelControl2.Controls.Add(label11);
            panelControl2.Controls.Add(label9);
            panelControl2.Controls.Add(label10);
            panelControl2.Controls.Add(tbBrand);
            panelControl2.Controls.Add(label13);
            panelControl2.Location = new Point(12, 106);
            panelControl2.Name = "panelControl2";
            panelControl2.Size = new Size(344, 460);
            panelControl2.TabIndex = 36;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(110, 27);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 30;
            label3.Text = "Thông tin";
            // 
            // tbName
            // 
            tbName.Location = new Point(126, 71);
            tbName.Name = "tbName";
            tbName.Size = new Size(204, 23);
            tbName.TabIndex = 1;
            // 
            // cbElec
            // 
            cbElec.AutoSize = true;
            cbElec.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbElec.Location = new Point(126, 394);
            cbElec.Margin = new Padding(2);
            cbElec.Name = "cbElec";
            cbElec.Size = new Size(70, 19);
            cbElec.TabIndex = 29;
            cbElec.Text = "Xe Điện";
            cbElec.UseVisualStyleBackColor = true;
            // 
            // tbType
            // 
            tbType.Location = new Point(126, 191);
            tbType.Name = "tbType";
            tbType.Size = new Size(204, 23);
            tbType.TabIndex = 4;
            // 
            // tbColor
            // 
            tbColor.Location = new Point(126, 231);
            tbColor.Name = "tbColor";
            tbColor.Size = new Size(204, 23);
            tbColor.TabIndex = 5;
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(126, 151);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(204, 23);
            tbEmail.TabIndex = 3;
            // 
            // tbLicensePlate
            // 
            tbLicensePlate.Location = new Point(126, 271);
            tbLicensePlate.Name = "tbLicensePlate";
            tbLicensePlate.Size = new Size(204, 23);
            tbLicensePlate.TabIndex = 6;
            // 
            // tbSdt
            // 
            tbSdt.Location = new Point(126, 111);
            tbSdt.Name = "tbSdt";
            tbSdt.Size = new Size(204, 23);
            tbSdt.TabIndex = 2;
            // 
            // tbAddress
            // 
            tbAddress.Location = new Point(126, 311);
            tbAddress.Name = "tbAddress";
            tbAddress.Size = new Size(204, 23);
            tbAddress.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F);
            label4.Location = new Point(21, 75);
            label4.Name = "label4";
            label4.Size = new Size(93, 15);
            label4.TabIndex = 12;
            label4.Text = "Mã phương tiện";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9F);
            label6.Location = new Point(22, 115);
            label6.Name = "label6";
            label6.Size = new Size(92, 15);
            label6.TabIndex = 13;
            label6.Text = "Mã khách hàng";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9F);
            label7.Location = new Point(9, 155);
            label7.Name = "label7";
            label7.Size = new Size(105, 15);
            label7.TabIndex = 14;
            label7.Text = "Hãng phương tiện";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F);
            label8.Location = new Point(15, 195);
            label8.Name = "label8";
            label8.Size = new Size(99, 15);
            label8.TabIndex = 15;
            label8.Text = "Loại phương tiện";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 9F);
            label11.Location = new Point(74, 355);
            label11.Name = "label11";
            label11.Size = new Size(40, 15);
            label11.TabIndex = 23;
            label11.Text = "ZONE";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9F);
            label9.Location = new Point(14, 235);
            label9.Name = "label9";
            label9.Size = new Size(100, 15);
            label9.TabIndex = 16;
            label9.Text = "Màu phương tiện";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 9F);
            label10.Location = new Point(50, 275);
            label10.Name = "label10";
            label10.Size = new Size(64, 15);
            label10.TabIndex = 17;
            label10.Text = "Biển số xe";
            // 
            // tbBrand
            // 
            tbBrand.Location = new Point(126, 351);
            tbBrand.Name = "tbBrand";
            tbBrand.Size = new Size(204, 23);
            tbBrand.TabIndex = 22;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 9F);
            label13.Location = new Point(52, 315);
            label13.Name = "label13";
            label13.Size = new Size(62, 15);
            label13.TabIndex = 21;
            label13.Text = "Tình trạng";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(178, 210, 182);
            panel1.Controls.Add(dataGridView1);
            panel1.Location = new Point(362, 103);
            panel1.Name = "panel1";
            panel1.Size = new Size(585, 463);
            panel1.TabIndex = 38;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 9);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(556, 437);
            dataGridView1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(178, 210, 182);
            label2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(375, 93);
            label2.Name = "label2";
            label2.Size = new Size(164, 16);
            label2.TabIndex = 0;
            label2.Text = "Danh sách phương tiện";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(375, 63);
            label5.Name = "label5";
            label5.Size = new Size(70, 16);
            label5.TabIndex = 39;
            label5.Text = "Tìm kiếm";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(451, 61);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(147, 23);
            textBox1.TabIndex = 40;
            // 
            // buttons1
            // 
            buttons1.BackColor = Color.FromArgb(255, 75, 8);
            buttons1.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons1.BorderColor = Color.PaleVioletRed;
            buttons1.BorderColor1 = Color.PaleVioletRed;
            buttons1.BorderRadius = 20;
            buttons1.BorderRadius1 = 20;
            buttons1.BorderSize = 0;
            buttons1.BorderSize1 = 0;
            buttons1.FlatAppearance.BorderSize = 0;
            buttons1.FlatStyle = FlatStyle.Flat;
            buttons1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons1.ForeColor = Color.White;
            buttons1.Location = new Point(613, 51);
            buttons1.Name = "buttons1";
            buttons1.Size = new Size(102, 40);
            buttons1.TabIndex = 41;
            buttons1.Text = "Cập nhật";
            buttons1.TextColor = Color.White;
            buttons1.UseVisualStyleBackColor = false;
            // 
            // buttons2
            // 
            buttons2.BackColor = Color.FromArgb(255, 75, 8);
            buttons2.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons2.BorderColor = Color.PaleVioletRed;
            buttons2.BorderColor1 = Color.PaleVioletRed;
            buttons2.BorderRadius = 20;
            buttons2.BorderRadius1 = 20;
            buttons2.BorderSize = 0;
            buttons2.BorderSize1 = 0;
            buttons2.FlatAppearance.BorderSize = 0;
            buttons2.FlatStyle = FlatStyle.Flat;
            buttons2.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons2.ForeColor = Color.White;
            buttons2.Location = new Point(721, 51);
            buttons2.Name = "buttons2";
            buttons2.Size = new Size(102, 40);
            buttons2.TabIndex = 42;
            buttons2.Text = "Xem tình trạng bãi";
            buttons2.TextColor = Color.White;
            buttons2.UseVisualStyleBackColor = false;
            // 
            // buttons3
            // 
            buttons3.BackColor = Color.FromArgb(255, 75, 8);
            buttons3.BackgroundColor = Color.FromArgb(255, 75, 8);
            buttons3.BorderColor = Color.PaleVioletRed;
            buttons3.BorderColor1 = Color.PaleVioletRed;
            buttons3.BorderRadius = 20;
            buttons3.BorderRadius1 = 20;
            buttons3.BorderSize = 0;
            buttons3.BorderSize1 = 0;
            buttons3.FlatAppearance.BorderSize = 0;
            buttons3.FlatStyle = FlatStyle.Flat;
            buttons3.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons3.ForeColor = Color.White;
            buttons3.Location = new Point(829, 51);
            buttons3.Name = "buttons3";
            buttons3.Size = new Size(102, 40);
            buttons3.TabIndex = 43;
            buttons3.Text = "Xuất file";
            buttons3.TextColor = Color.White;
            buttons3.UseVisualStyleBackColor = false;
            // 
            // UCQuanLyBaiGiuXe
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            Controls.Add(buttons3);
            Controls.Add(buttons2);
            Controls.Add(buttons1);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label2);
            Controls.Add(panel1);
            Controls.Add(label1);
            Controls.Add(panelControl2);
            Name = "UCQuanLyBaiGiuXe";
            Size = new Size(950, 580);
            panelControl2.ResumeLayout(false);
            panelControl2.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Controls.PanelControl panelControl2;
        private Label label3;
        private TextBox tbName;
        private CheckBox cbElec;
        private TextBox tbType;
        private TextBox tbColor;
        private TextBox tbEmail;
        private TextBox tbLicensePlate;
        private TextBox tbSdt;
        private TextBox tbAddress;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label11;
        private Label label9;
        private Label label10;
        private TextBox tbBrand;
        private Label label13;
        private Panel panel1;
        private Label label2;
        private Label label5;
        private TextBox textBox1;
        private Controls.Buttons buttons1;
        private Controls.Buttons buttons2;
        private Controls.Buttons buttons3;
        private DataGridView dataGridView1;
    }
}
