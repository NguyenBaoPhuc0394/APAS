﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.Controls
{
    public class GGSheetsService
    {
        private static GGSheetsService instance;

        public static GGSheetsService Instance {
            get { 
                if(instance == null)
                    instance = new GGSheetsService();
                return instance;
            }
            set => instance = value; 
        }

        private GGSheetsService() { }

        public SheetsService GetServices()
        {
            string[] scopes = { SheetsService.Scope.Spreadsheets };
            string serviceAccountKeyFilePath = "credential.json";
            GoogleCredential credential;
            using (var stream = new FileStream(serviceAccountKeyFilePath, FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream).CreateScoped(scopes);
            }
            var sheetService = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "Your Application Name",
            });
            return sheetService;
        }

        public int GetSheetId(string spreadsheetId, string sheetName)
        {
            var service = GetServices();

            var spreadsheet = service.Spreadsheets.Get(spreadsheetId).Execute();
            var sheet = spreadsheet.Sheets.FirstOrDefault(s => s.Properties.Title == sheetName);

            return sheet?.Properties.SheetId ?? -1;
        }
    }
}
