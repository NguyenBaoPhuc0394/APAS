﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace APAS_0.Controls
{
    public class RoundedTextBox : TextBox
    {
        // Fields
        private int borderSize = 2;
        private int borderRadius = 20;
        private Color borderColor = Color.PaleVioletRed;

        // Properties
        public int BorderSize
        {
            get { return borderSize; }
            set
            {
                borderSize = value;
                this.Invalidate();
            }
        }

        public int BorderRadius
        {
            get { return borderRadius; }
            set
            {
                borderRadius = value;
                this.Invalidate();
            }
        }

        public Color BorderColor
        {
            get { return borderColor; }
            set
            {
                borderColor = value;
                this.Invalidate();
            }
        }

        public RoundedTextBox()
        {
            this.Multiline = false;
            this.BackColor = Color.White;
            this.ForeColor = Color.Black;
            this.BorderStyle = BorderStyle.None; // Remove default border
            this.Size = new Size(150, 40); // Set default size
        }

        // Methods
        private GraphicsPath GetFigurePath(Rectangle rect, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            float curveSize = radius * 2F;

            path.StartFigure();
            path.AddArc(rect.X, rect.Y, curveSize, curveSize, 180, 90);
            path.AddArc(rect.Right - curveSize, rect.Y, curveSize, curveSize, 270, 90);
            path.AddArc(rect.Right - curveSize, rect.Bottom - curveSize, curveSize, curveSize, 0, 90);
            path.AddArc(rect.X, rect.Bottom - curveSize, curveSize, curveSize, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            // Set smoothing mode for better rendering quality
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Create paths for the surface and border
            GraphicsPath pathSurface = GetFigurePath(this.ClientRectangle, borderRadius);
            GraphicsPath pathBorder = GetFigurePath(Rectangle.Inflate(this.ClientRectangle, -borderSize, -borderSize), borderRadius - borderSize);

            // Fill the background
            using (SolidBrush brush = new SolidBrush(this.BackColor))
            {
                e.Graphics.FillPath(brush, pathSurface);
            }

            // Draw the border
            using (Pen penBorder = new Pen(borderColor, borderSize))
            {
                e.Graphics.DrawPath(penBorder, pathBorder);
            }

            // Set the region for rounded corners
            this.Region = new Region(pathSurface);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            // Refresh when parent back color changes
            this.Parent.BackColorChanged += (s, args) => this.Invalidate();
        }
    }
}

