﻿namespace APAS_0.Controls
{
    partial class TextBoxControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt = new TextBox();
            SuspendLayout();
            // 
            // txt
            // 
            txt.BackColor = SystemColors.Window;
            txt.BorderStyle = BorderStyle.None;
            txt.Dock = DockStyle.Fill;
            txt.ForeColor = SystemColors.Window;
            txt.Location = new Point(10, 7);
            txt.Name = "txt";
            txt.Size = new Size(230, 16);
            txt.TabIndex = 0;
            // 
            // TextBoxControl
            // 
            AutoScaleMode = AutoScaleMode.None;
            Controls.Add(txt);
            Name = "TextBoxControl";
            Padding = new Padding(10, 7, 10, 7);
            Size = new Size(250, 30);
            Load += TextBoxControl_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt;
    }
}
