﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.ComponentModel;

namespace APAS_0.Controls
{
    public class PanelControl : Panel
    {
        private int borderRadius = 20; // Độ bo tròn

        public int BorderRadius
        {
            get { return borderRadius; }
            set
            {
                borderRadius = value;
                this.Invalidate(); // Vẽ lại panel khi thay đổi độ bo tròn
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias; // Làm mịn các đường vẽ

            using (GraphicsPath path = GetFigurePath(this.ClientRectangle, borderRadius))
            {
                this.Region = new Region(path); // Thiết lập vùng cho panel
                e.Graphics.FillPath(new SolidBrush(this.BackColor), path); // Vẽ màu nền cho panel
                //e.Graphics.DrawPath(new Pen(this.BorderColor, 1), path); // Vẽ đường viền nếu cần
            }
        }

        private GraphicsPath GetFigurePath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            path.StartFigure();
            path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
            path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
            path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
            path.CloseFigure();
            return path;
        }
    }
}
