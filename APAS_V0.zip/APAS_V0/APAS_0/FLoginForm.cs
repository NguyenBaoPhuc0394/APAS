﻿using APAS_0.Controls;
using APAS_0.DAL;
using APAS_0.DTO;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace APAS_0
{
    public partial class FLoginForm : Form
    {
        public FLoginForm()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]

        private static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]

        private static extern bool ReleaseCapture();

        private void Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void BtnMaximize_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Minimized;
            }
            else if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void FLoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có thật sự muốn thoát?", "Thông báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void btnShowOrHidden_Click(object sender, EventArgs e)
        {
            if (tbPassWord.UseSystemPasswordChar == false)
            {
                tbPassWord.UseSystemPasswordChar = true;
                btnShowOrHidden.Image = Properties.Resources.hidden;
            }
            else
            {
                tbPassWord.UseSystemPasswordChar = false;
                btnShowOrHidden.Image = Properties.Resources.eye;
            }
        }

        private void llbResetPassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FResetPassword frs = new FResetPassword();
            this.Hide();
            frs.ShowDialog();
            this.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //FQuanLyTaiKhoan ql = new FQuanLyTaiKhoan();
            //this.Hide();
            //ql.ShowDialog();
            //this.Show();
            string username = tbUsername.Text;
            string password = tbPassWord.Text;
            if (loginSuccess(username, password))
            {
                NhanVien nv = TaiKhoanDAL.Instance.GetNhanVienFromLoginInfor(username, password);
                if (nv != null)
                {
                    FMain f = new FMain(nv);
                    this.Hide();
                    f.ShowDialog();
                    this.Show();
                }
            }
            else
            {
                MessageBox.Show("Đăng nhập thất bại! Vui lòng đăng nhập lại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool loginSuccess(string username, string password)
        {
            return TaiKhoanDAL.Instance.CheckAccount(username, password);
        }
    }
}
