﻿namespace APAS_0
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
            pictureBox1 = new PictureBox();
            btnAdd = new Controls.Buttons();
            panelControl1 = new Controls.PanelControl();
            btnInfoPersonal = new Controls.Buttons();
            btnPay = new Controls.Buttons();
            btnProblem = new Controls.Buttons();
            btnParkingLot = new Controls.Buttons();
            btnServices = new Controls.Buttons();
            btnNotify = new Controls.Buttons();
            pnlShowUC = new Panel();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelControl1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Dọc___màu;
            pictureBox1.Location = new Point(14, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(255, 75, 8);
            btnAdd.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnAdd.BorderColor = Color.PaleVioletRed;
            btnAdd.BorderColor1 = Color.PaleVioletRed;
            btnAdd.BorderRadius = 20;
            btnAdd.BorderRadius1 = 20;
            btnAdd.BorderSize = 0;
            btnAdd.BorderSize1 = 0;
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(14, 67);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(123, 40);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Thêm dịch vụ";
            btnAdd.TextColor = Color.White;
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += BtnAdd_Click;
            // 
            // panelControl1
            // 
            panelControl1.BackColor = Color.FromArgb(92, 129, 87);
            panelControl1.BorderRadius = 50;
            panelControl1.Controls.Add(btnInfoPersonal);
            panelControl1.Controls.Add(btnPay);
            panelControl1.Controls.Add(btnProblem);
            panelControl1.Controls.Add(btnParkingLot);
            panelControl1.Controls.Add(btnServices);
            panelControl1.Controls.Add(btnNotify);
            panelControl1.Controls.Add(btnAdd);
            panelControl1.Font = new Font("Microsoft Sans Serif", 9.75F);
            panelControl1.Location = new Point(6, 130);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(150, 405);
            panelControl1.TabIndex = 31;
            // 
            // btnInfoPersonal
            // 
            btnInfoPersonal.BackColor = Color.FromArgb(255, 75, 8);
            btnInfoPersonal.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnInfoPersonal.BorderColor = Color.PaleVioletRed;
            btnInfoPersonal.BorderColor1 = Color.PaleVioletRed;
            btnInfoPersonal.BorderRadius = 20;
            btnInfoPersonal.BorderRadius1 = 20;
            btnInfoPersonal.BorderSize = 0;
            btnInfoPersonal.BorderSize1 = 0;
            btnInfoPersonal.FlatAppearance.BorderSize = 0;
            btnInfoPersonal.FlatStyle = FlatStyle.Flat;
            btnInfoPersonal.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInfoPersonal.ForeColor = Color.White;
            btnInfoPersonal.Location = new Point(14, 11);
            btnInfoPersonal.Name = "btnInfoPersonal";
            btnInfoPersonal.Size = new Size(123, 40);
            btnInfoPersonal.TabIndex = 13;
            btnInfoPersonal.Text = "Thông tin cá nhân";
            btnInfoPersonal.TextColor = Color.White;
            btnInfoPersonal.UseVisualStyleBackColor = false;
            btnInfoPersonal.Click += BtnInfoPersonal_Click;
            // 
            // btnPay
            // 
            btnPay.BackColor = Color.FromArgb(255, 75, 8);
            btnPay.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnPay.BorderColor = Color.PaleVioletRed;
            btnPay.BorderColor1 = Color.PaleVioletRed;
            btnPay.BorderRadius = 20;
            btnPay.BorderRadius1 = 20;
            btnPay.BorderSize = 0;
            btnPay.BorderSize1 = 0;
            btnPay.FlatAppearance.BorderSize = 0;
            btnPay.FlatStyle = FlatStyle.Flat;
            btnPay.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnPay.ForeColor = Color.White;
            btnPay.Location = new Point(14, 347);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(123, 40);
            btnPay.TabIndex = 12;
            btnPay.Text = "Thanh toán";
            btnPay.TextColor = Color.White;
            btnPay.UseVisualStyleBackColor = false;
            btnPay.Click += BtnPay_Click;
            // 
            // btnProblem
            // 
            btnProblem.BackColor = Color.FromArgb(255, 75, 8);
            btnProblem.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnProblem.BorderColor = Color.PaleVioletRed;
            btnProblem.BorderColor1 = Color.PaleVioletRed;
            btnProblem.BorderRadius = 20;
            btnProblem.BorderRadius1 = 20;
            btnProblem.BorderSize = 0;
            btnProblem.BorderSize1 = 0;
            btnProblem.FlatAppearance.BorderSize = 0;
            btnProblem.FlatStyle = FlatStyle.Flat;
            btnProblem.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnProblem.ForeColor = Color.White;
            btnProblem.Location = new Point(14, 291);
            btnProblem.Name = "btnProblem";
            btnProblem.Size = new Size(123, 40);
            btnProblem.TabIndex = 11;
            btnProblem.Text = "Sự cố";
            btnProblem.TextColor = Color.White;
            btnProblem.UseVisualStyleBackColor = false;
            btnProblem.Click += BtnProblem_Click;
            // 
            // btnParkingLot
            // 
            btnParkingLot.BackColor = Color.FromArgb(255, 75, 8);
            btnParkingLot.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnParkingLot.BorderColor = Color.PaleVioletRed;
            btnParkingLot.BorderColor1 = Color.PaleVioletRed;
            btnParkingLot.BorderRadius = 20;
            btnParkingLot.BorderRadius1 = 20;
            btnParkingLot.BorderSize = 0;
            btnParkingLot.BorderSize1 = 0;
            btnParkingLot.FlatAppearance.BorderSize = 0;
            btnParkingLot.FlatStyle = FlatStyle.Flat;
            btnParkingLot.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnParkingLot.ForeColor = Color.White;
            btnParkingLot.Location = new Point(14, 235);
            btnParkingLot.Name = "btnParkingLot";
            btnParkingLot.Size = new Size(123, 40);
            btnParkingLot.TabIndex = 10;
            btnParkingLot.Text = "Bãi giữ xe";
            btnParkingLot.TextColor = Color.White;
            btnParkingLot.UseVisualStyleBackColor = false;
            btnParkingLot.Click += BtnParkingLot_Click;
            // 
            // btnServices
            // 
            btnServices.BackColor = Color.FromArgb(255, 75, 8);
            btnServices.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnServices.BorderColor = Color.PaleVioletRed;
            btnServices.BorderColor1 = Color.PaleVioletRed;
            btnServices.BorderRadius = 20;
            btnServices.BorderRadius1 = 20;
            btnServices.BorderSize = 0;
            btnServices.BorderSize1 = 0;
            btnServices.FlatAppearance.BorderSize = 0;
            btnServices.FlatStyle = FlatStyle.Flat;
            btnServices.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnServices.ForeColor = Color.White;
            btnServices.Location = new Point(14, 123);
            btnServices.Name = "btnServices";
            btnServices.Size = new Size(123, 40);
            btnServices.TabIndex = 9;
            btnServices.Text = "Dịch vụ";
            btnServices.TextColor = Color.White;
            btnServices.UseVisualStyleBackColor = false;
            btnServices.Click += BtnServices_Click;
            // 
            // btnNotify
            // 
            btnNotify.BackColor = Color.FromArgb(255, 75, 8);
            btnNotify.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnNotify.BorderColor = Color.PaleVioletRed;
            btnNotify.BorderColor1 = Color.PaleVioletRed;
            btnNotify.BorderRadius = 20;
            btnNotify.BorderRadius1 = 20;
            btnNotify.BorderSize = 0;
            btnNotify.BorderSize1 = 0;
            btnNotify.FlatAppearance.BorderSize = 0;
            btnNotify.FlatStyle = FlatStyle.Flat;
            btnNotify.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnNotify.ForeColor = Color.White;
            btnNotify.Location = new Point(14, 179);
            btnNotify.Name = "btnNotify";
            btnNotify.Size = new Size(123, 40);
            btnNotify.TabIndex = 8;
            btnNotify.Text = "Thông báo";
            btnNotify.TextColor = Color.White;
            btnNotify.UseVisualStyleBackColor = false;
            // 
            // pnlShowUC
            // 
            pnlShowUC.Location = new Point(160, 2);
            pnlShowUC.Name = "pnlShowUC";
            pnlShowUC.Size = new Size(950, 580);
            pnlShowUC.TabIndex = 32;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(6, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(148, 112);
            panel1.TabIndex = 33;
            // 
            // FManHinhChinh
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            ClientSize = new Size(1110, 591);
            Controls.Add(panel1);
            Controls.Add(pnlShowUC);
            Controls.Add(panelControl1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FManHinhChinh";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "APAS";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelControl1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pictureBox1;
        private Controls.Buttons btnAdd;
        private Controls.PanelControl panelControl1;
        private Controls.Buttons btnServices;
        private Controls.Buttons btnNotify;
        private Controls.Buttons btnProblem;
        private Controls.Buttons btnParkingLot;
        private Controls.Buttons btnPay;
        private Panel pnlShowUC;
        private Controls.Buttons btnInfoPersonal;
        private Panel panel1;
    }
}