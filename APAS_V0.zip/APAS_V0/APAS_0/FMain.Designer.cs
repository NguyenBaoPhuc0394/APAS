﻿namespace APAS_0
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
            pictureBox1 = new PictureBox();
            btnAdd = new Controls.Buttons();
            panelControl1 = new Controls.PanelControl();
            buttons1 = new Controls.Buttons();
            btnStatistics = new Controls.Buttons();
            btnAccount = new Controls.Buttons();
            btnPay = new Controls.Buttons();
            btnProblem = new Controls.Buttons();
            btnParkingLot = new Controls.Buttons();
            btnServices = new Controls.Buttons();
            btnNotify = new Controls.Buttons();
            pnlShowUC = new Panel();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelControl1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Dọc___màu;
            pictureBox1.Location = new Point(14, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(255, 75, 8);
            btnAdd.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnAdd.BorderColor = Color.PaleVioletRed;
            btnAdd.BorderColor1 = Color.PaleVioletRed;
            btnAdd.BorderRadius = 15;
            btnAdd.BorderRadius1 = 15;
            btnAdd.BorderSize = 0;
            btnAdd.BorderSize1 = 0;
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.ForeColor = Color.White;
            btnAdd.Image = Properties.Resources.image_gallery;
            btnAdd.Location = new Point(14, 60);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(123, 40);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "  Thêm ";
            btnAdd.TextColor = Color.White;
            btnAdd.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += BtnAdd_Click;
            // 
            // panelControl1
            // 
            panelControl1.BackColor = Color.FromArgb(92, 129, 87);
            panelControl1.BorderRadius = 50;
            panelControl1.Controls.Add(buttons1);
            panelControl1.Controls.Add(btnStatistics);
            panelControl1.Controls.Add(btnAccount);
            panelControl1.Controls.Add(btnPay);
            panelControl1.Controls.Add(btnProblem);
            panelControl1.Controls.Add(btnParkingLot);
            panelControl1.Controls.Add(btnServices);
            panelControl1.Controls.Add(btnNotify);
            panelControl1.Controls.Add(btnAdd);
            panelControl1.Font = new Font("Microsoft Sans Serif", 9.75F);
            panelControl1.Location = new Point(6, 114);
            panelControl1.Name = "panelControl1";
            panelControl1.Size = new Size(150, 468);
            panelControl1.TabIndex = 31;
            // 
            // buttons1
            // 
            buttons1.BackColor = Color.Red;
            buttons1.BackgroundColor = Color.Red;
            buttons1.BorderColor = Color.PaleVioletRed;
            buttons1.BorderColor1 = Color.PaleVioletRed;
            buttons1.BorderRadius = 15;
            buttons1.BorderRadius1 = 15;
            buttons1.BorderSize = 0;
            buttons1.BorderSize1 = 0;
            buttons1.FlatAppearance.BorderSize = 0;
            buttons1.FlatStyle = FlatStyle.Flat;
            buttons1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            buttons1.ForeColor = Color.White;
            buttons1.Image = Properties.Resources.logout;
            buttons1.Location = new Point(14, 410);
            buttons1.Name = "buttons1";
            buttons1.Size = new Size(123, 40);
            buttons1.TabIndex = 15;
            buttons1.Text = "Đăng xuất";
            buttons1.TextColor = Color.White;
            buttons1.TextImageRelation = TextImageRelation.ImageBeforeText;
            buttons1.UseVisualStyleBackColor = false;
            // 
            // btnStatistics
            // 
            btnStatistics.BackColor = Color.FromArgb(255, 75, 8);
            btnStatistics.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnStatistics.BorderColor = Color.PaleVioletRed;
            btnStatistics.BorderColor1 = Color.PaleVioletRed;
            btnStatistics.BorderRadius = 15;
            btnStatistics.BorderRadius1 = 15;
            btnStatistics.BorderSize = 0;
            btnStatistics.BorderSize1 = 0;
            btnStatistics.FlatAppearance.BorderSize = 0;
            btnStatistics.FlatStyle = FlatStyle.Flat;
            btnStatistics.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnStatistics.ForeColor = Color.White;
            btnStatistics.Image = Properties.Resources.statistics;
            btnStatistics.Location = new Point(14, 360);
            btnStatistics.Name = "btnStatistics";
            btnStatistics.Size = new Size(123, 40);
            btnStatistics.TabIndex = 14;
            btnStatistics.Text = "Thống kê";
            btnStatistics.TextColor = Color.White;
            btnStatistics.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnStatistics.UseVisualStyleBackColor = false;
            btnStatistics.Click += BtnStatistics_Click;
            // 
            // btnAccount
            // 
            btnAccount.BackColor = Color.FromArgb(255, 75, 8);
            btnAccount.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnAccount.BorderColor = Color.PaleVioletRed;
            btnAccount.BorderColor1 = Color.PaleVioletRed;
            btnAccount.BorderRadius = 15;
            btnAccount.BorderRadius1 = 15;
            btnAccount.BorderSize = 0;
            btnAccount.BorderSize1 = 0;
            btnAccount.FlatAppearance.BorderSize = 0;
            btnAccount.FlatStyle = FlatStyle.Flat;
            btnAccount.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAccount.ForeColor = Color.White;
            btnAccount.Image = Properties.Resources.id_card;
            btnAccount.Location = new Point(14, 10);
            btnAccount.Name = "btnAccount";
            btnAccount.Size = new Size(123, 40);
            btnAccount.TabIndex = 13;
            btnAccount.Text = "Tài khoản";
            btnAccount.TextColor = Color.White;
            btnAccount.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnAccount.UseVisualStyleBackColor = false;
            btnAccount.Click += BtnInfoPersonal_Click;
            // 
            // btnPay
            // 
            btnPay.BackColor = Color.FromArgb(255, 75, 8);
            btnPay.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnPay.BorderColor = Color.PaleVioletRed;
            btnPay.BorderColor1 = Color.PaleVioletRed;
            btnPay.BorderRadius = 15;
            btnPay.BorderRadius1 = 15;
            btnPay.BorderSize = 0;
            btnPay.BorderSize1 = 0;
            btnPay.FlatAppearance.BorderSize = 0;
            btnPay.FlatStyle = FlatStyle.Flat;
            btnPay.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnPay.ForeColor = Color.White;
            btnPay.Image = Properties.Resources.coin;
            btnPay.Location = new Point(14, 310);
            btnPay.Name = "btnPay";
            btnPay.Size = new Size(123, 40);
            btnPay.TabIndex = 12;
            btnPay.Text = "Thanh toán";
            btnPay.TextColor = Color.White;
            btnPay.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnPay.UseVisualStyleBackColor = false;
            btnPay.Click += BtnPay_Click;
            // 
            // btnProblem
            // 
            btnProblem.BackColor = Color.FromArgb(255, 75, 8);
            btnProblem.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnProblem.BorderColor = Color.PaleVioletRed;
            btnProblem.BorderColor1 = Color.PaleVioletRed;
            btnProblem.BorderRadius = 15;
            btnProblem.BorderRadius1 = 15;
            btnProblem.BorderSize = 0;
            btnProblem.BorderSize1 = 0;
            btnProblem.FlatAppearance.BorderSize = 0;
            btnProblem.FlatStyle = FlatStyle.Flat;
            btnProblem.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnProblem.ForeColor = Color.White;
            btnProblem.Image = Properties.Resources.warning;
            btnProblem.Location = new Point(14, 260);
            btnProblem.Name = "btnProblem";
            btnProblem.Size = new Size(123, 40);
            btnProblem.TabIndex = 11;
            btnProblem.Text = "  Sự cố";
            btnProblem.TextColor = Color.White;
            btnProblem.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnProblem.UseVisualStyleBackColor = false;
            btnProblem.Click += BtnProblem_Click;
            // 
            // btnParkingLot
            // 
            btnParkingLot.BackColor = Color.FromArgb(255, 75, 8);
            btnParkingLot.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnParkingLot.BorderColor = Color.PaleVioletRed;
            btnParkingLot.BorderColor1 = Color.PaleVioletRed;
            btnParkingLot.BorderRadius = 15;
            btnParkingLot.BorderRadius1 = 15;
            btnParkingLot.BorderSize = 0;
            btnParkingLot.BorderSize1 = 0;
            btnParkingLot.FlatAppearance.BorderSize = 0;
            btnParkingLot.FlatStyle = FlatStyle.Flat;
            btnParkingLot.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnParkingLot.ForeColor = Color.White;
            btnParkingLot.Image = Properties.Resources.car;
            btnParkingLot.Location = new Point(14, 210);
            btnParkingLot.Name = "btnParkingLot";
            btnParkingLot.Size = new Size(123, 40);
            btnParkingLot.TabIndex = 10;
            btnParkingLot.Text = "Bãi giữ xe";
            btnParkingLot.TextColor = Color.White;
            btnParkingLot.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnParkingLot.UseVisualStyleBackColor = false;
            btnParkingLot.Click += BtnParkingLot_Click;
            // 
            // btnServices
            // 
            btnServices.BackColor = Color.FromArgb(255, 75, 8);
            btnServices.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnServices.BorderColor = Color.PaleVioletRed;
            btnServices.BorderColor1 = Color.PaleVioletRed;
            btnServices.BorderRadius = 15;
            btnServices.BorderRadius1 = 15;
            btnServices.BorderSize = 0;
            btnServices.BorderSize1 = 0;
            btnServices.FlatAppearance.BorderSize = 0;
            btnServices.FlatStyle = FlatStyle.Flat;
            btnServices.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnServices.ForeColor = Color.White;
            btnServices.Image = Properties.Resources.fleet_management;
            btnServices.Location = new Point(14, 110);
            btnServices.Name = "btnServices";
            btnServices.Size = new Size(123, 40);
            btnServices.TabIndex = 9;
            btnServices.Text = "  Dịch vụ";
            btnServices.TextColor = Color.White;
            btnServices.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnServices.UseVisualStyleBackColor = false;
            btnServices.Click += BtnServices_Click;
            // 
            // btnNotify
            // 
            btnNotify.BackColor = Color.FromArgb(255, 75, 8);
            btnNotify.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnNotify.BorderColor = Color.PaleVioletRed;
            btnNotify.BorderColor1 = Color.PaleVioletRed;
            btnNotify.BorderRadius = 15;
            btnNotify.BorderRadius1 = 15;
            btnNotify.BorderSize = 0;
            btnNotify.BorderSize1 = 0;
            btnNotify.FlatAppearance.BorderSize = 0;
            btnNotify.FlatStyle = FlatStyle.Flat;
            btnNotify.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            btnNotify.ForeColor = Color.White;
            btnNotify.Image = Properties.Resources.ringing;
            btnNotify.Location = new Point(14, 160);
            btnNotify.Name = "btnNotify";
            btnNotify.Size = new Size(123, 40);
            btnNotify.TabIndex = 8;
            btnNotify.Text = "Thông báo";
            btnNotify.TextColor = Color.White;
            btnNotify.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnNotify.UseVisualStyleBackColor = false;
            // 
            // pnlShowUC
            // 
            pnlShowUC.Location = new Point(160, 2);
            pnlShowUC.Name = "pnlShowUC";
            pnlShowUC.Size = new Size(950, 580);
            pnlShowUC.TabIndex = 32;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(6, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(148, 96);
            panel1.TabIndex = 33;
            // 
            // FMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            ClientSize = new Size(1110, 591);
            Controls.Add(panel1);
            Controls.Add(pnlShowUC);
            Controls.Add(panelControl1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "FMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "APAS";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelControl1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pictureBox1;
        private Controls.Buttons btnAdd;
        private Controls.PanelControl panelControl1;
        private Controls.Buttons btnServices;
        private Controls.Buttons btnNotify;
        private Controls.Buttons btnProblem;
        private Controls.Buttons btnParkingLot;
        private Controls.Buttons btnPay;
        private Panel pnlShowUC;
        private Controls.Buttons btnAccount;
        private Panel panel1;
        private Controls.Buttons btnStatistics;
        private Controls.Buttons buttons1;
    }
}