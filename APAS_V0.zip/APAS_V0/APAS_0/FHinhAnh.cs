﻿using APAS_0.Controls;
using APAS_0.DAL;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Services;
using QRCoder;
using System.Net;
using System.Net.Mail;
using static QRCoder.PayloadGenerator;

namespace APAS_0
{
    public partial class FHinhAnh : Form
    {
        private string hoTen;
        private string sdt;
        private string ngayDK;
        private string ngayHH;
        private string staff;
        private string hinhanh;
        private string bsx;

        public string HoTen { get => hoTen; set => hoTen = value; }
        public string Sdt { get => sdt; set => sdt = value; }
        public string NgayDK { get => ngayDK; set => ngayDK = value; }
        public string NgayHH { get => ngayHH; set => ngayHH = value; }
        public string Staff { get => staff; set => staff = value; }
        public string Hinhanh { get => hinhanh; set => hinhanh = value; }
        public string Bsx { get => bsx; set => bsx = value; }

        public FHinhAnh(string hoTen, string sdt, string ngayDK, string ngayHH, string staff, string bsx, string hinhanh)
        {
            InitializeComponent();
            HoTen = hoTen;
            Sdt = sdt;
            NgayDK = ngayDK;
            NgayHH = ngayHH;
            Staff = staff;
            Bsx = bsx;
            if (hinhanh != null) {
                Hinhanh = hinhanh;
            }
            else
                Hinhanh = DichVuDAL.Instance.GetHinhAnhFromBSX(Bsx);
        }

        private void FHinhAnh_Load(object sender, EventArgs e)
        {
            if (Hinhanh != "" && System.IO.File.Exists(Hinhanh)) {
                ptbImage.Image = Image.FromFile(Hinhanh);
                ptbImage.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                if (ptbImage.Image != null)
                {
                    ptbImage.Image.Dispose();
                    ptbImage.Image = null;
                }
                ptbImage.Image = Image.FromFile(filePath);
                ptbImage.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private Image AddTextToImage(Image image)
        {
            Image newImg = (Image)image.Clone();
            using (Graphics g = Graphics.FromImage(newImg))
            {
                Font font = new Font("Arial", 9, FontStyle.Bold);
                Brush brush = new SolidBrush(Color.Red);
                g.DrawString($"Khách hàng: {this.HoTen}", font, brush, new PointF(10, 10));
                g.DrawString($"Số điện thoại: {this.Sdt}", font, brush, new PointF(10, 35));
                g.DrawString($"Ngày đăng ký: {this.NgayDK}", font, brush, new PointF(10, 60));
                g.DrawString($"Ngày hết hạn: {this.NgayHH}", font, brush, new PointF(10, 85));
                g.DrawString($"Nhân viên phụ trách: {this.Staff}", font, brush, new PointF(10, 110));
            }
            return newImg;
        }

        private string SaveImage(Image image, string savePath)
        {
            image.Save(savePath, System.Drawing.Imaging.ImageFormat.Jpeg);
            return savePath;
        }

        private static DriveService GetDriveService()
        {
            var credential = GoogleCredential.FromFile("credential.json")
                             .CreateScoped(DriveService.Scope.DriveFile);

            var service = new DriveService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "My App Name",
            });

            return service;
        }

        private static string UploadFileToDrive(string filePath, string folderId)
        {
            var service = GetDriveService();

            var fileMetadata = new Google.Apis.Drive.v3.Data.File()
            {
                Name = Path.GetFileName(filePath),
                Parents = new List<string> { folderId }
            };
            FilesResource.CreateMediaUpload request;
            using (var stream = new FileStream(filePath, FileMode.Open))
            {
                request = service.Files.Create(fileMetadata, stream, "image/jpeg");
                request.Fields = "id";
                request.Upload();
            }
            var file = request.ResponseBody;
            MessageBox.Show("File uploaded to Google Drive with ID: " + file.Id);

            var permission = new Permission
            {
                Type = "anyone",
                Role = "reader"
            };
            service.Permissions.Create(permission, file.Id).Execute();

            string fileLink = $"https://drive.google.com/uc?id={file.Id}";

            return fileLink;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (ptbImage.Image != null)
            {
                Image image = Image.FromFile(openFileDialog.FileName);
                Image newImage = AddTextToImage(image);


                string folderPath = Path.Combine(Application.StartupPath, "Images");
                string savePath = Path.Combine(folderPath, $"{this.Bsx}.jpg");
                string newFilePath = SaveImage(newImage, savePath);
                this.Hinhanh = newFilePath;
                string fileLink = UploadFileToDrive(newFilePath, "1yJAChcJ4tGEXBRt_2UT7iS56tgOWHhhs");

                Bitmap qrCodeImage = QR.Instance.GenerateQRCode(fileLink);
                string folderPathQR = Path.Combine(Application.StartupPath, "QRCode");
                string saveQR = Path.Combine(folderPathQR, $"{this.Bsx}.jpg");
                string fileQR = SaveImage(qrCodeImage, saveQR);

                //btnSendMail.Tag = fileQR;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        


        //private void btnSendMail_Click(object sender, EventArgs e)
        //{
        //    SendMailWithQR("pbao584@gmail.com", "BaoPhuc", btnSendMail.Tag.ToString());
        //}

        //private void SendMailWithQR(string recipient, string sender, string qrFile)
        //{
        //    string senderMail = "nguyenbaophuc564@gmail.com";
        //    string senderPassword = "DominicBP.394";
        //    MailMessage mailMessage = new MailMessage();
        //    mailMessage.From = new MailAddress(senderMail, sender);
        //    mailMessage.To.Add(recipient);
        //    mailMessage.Subject = "QR code and sender's name";
        //    mailMessage.Body = "QR code and sender's name";
        //    Attachment attachment = new Attachment(qrFile);
        //    mailMessage.Attachments.Add(attachment);

        //    SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587)
        //    {
        //        Credentials = new NetworkCredential(senderMail, senderPassword),
        //        EnableSsl = true,
        //        DeliveryMethod = SmtpDeliveryMethod.Network
        //    };

        //    try
        //    {
        //        smtpClient.Send(mailMessage);
        //        MessageBox.Show("Email sent successfully.");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Failed to send email: " + ex.Message);
        //    }
        //    finally
        //    {
        //        attachment.Dispose();
        //        mailMessage.Dispose();
        //    }

        //}
    }
}
