﻿namespace APAS_0
{
    partial class FResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FResetPassword));
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnChangePassword = new Button();
            llbLogin = new LinkLabel();
            tbGmail = new TextBox();
            tbID = new TextBox();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            tbPassword = new TextBox();
            label4 = new Label();
            label5 = new Label();
            tbRePassword = new TextBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            btn1 = new Button();
            btn2 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(601, 101);
            label3.Name = "label3";
            label3.Size = new Size(253, 38);
            label3.TabIndex = 10;
            label3.Text = "Quên mật khẩu";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(553, 319);
            label2.Name = "label2";
            label2.Size = new Size(57, 25);
            label2.TabIndex = 8;
            label2.Text = "Gmail";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(553, 230);
            label1.Name = "label1";
            label1.Size = new Size(115, 25);
            label1.TabIndex = 7;
            label1.Text = "Mã tài khoản";
            // 
            // btnChangePassword
            // 
            btnChangePassword.AutoSize = true;
            btnChangePassword.BackColor = Color.FromArgb(46, 177, 255);
            btnChangePassword.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnChangePassword.Location = new Point(622, 599);
            btnChangePassword.Margin = new Padding(3, 5, 3, 5);
            btnChangePassword.Name = "btnChangePassword";
            btnChangePassword.Size = new Size(217, 86);
            btnChangePassword.TabIndex = 6;
            btnChangePassword.Text = "Đổi mật khẩu";
            btnChangePassword.UseVisualStyleBackColor = false;
            btnChangePassword.Click += button1_Click;
            // 
            // llbLogin
            // 
            llbLogin.AutoSize = true;
            llbLogin.Location = new Point(844, 565);
            llbLogin.Name = "llbLogin";
            llbLogin.Size = new Size(103, 25);
            llbLogin.TabIndex = 5;
            llbLogin.TabStop = true;
            llbLogin.Text = "Đăng Nhập";
            llbLogin.LinkClicked += linkLabel1_LinkClicked;
            // 
            // tbGmail
            // 
            tbGmail.Location = new Point(547, 349);
            tbGmail.Margin = new Padding(3, 5, 3, 5);
            tbGmail.Name = "tbGmail";
            tbGmail.Size = new Size(392, 31);
            tbGmail.TabIndex = 4;
            // 
            // tbID
            // 
            tbID.Location = new Point(547, 260);
            tbID.Margin = new Padding(3, 5, 3, 5);
            tbID.Name = "tbID";
            tbID.Size = new Size(392, 31);
            tbID.TabIndex = 3;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(46, 177, 255);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 5, 3, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(431, 702);
            panel1.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(93, 195);
            pictureBox1.Margin = new Padding(3, 5, 3, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(232, 285);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // tbPassword
            // 
            tbPassword.Location = new Point(549, 428);
            tbPassword.Margin = new Padding(3, 5, 3, 5);
            tbPassword.Name = "tbPassword";
            tbPassword.Size = new Size(388, 31);
            tbPassword.TabIndex = 12;
            tbPassword.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(553, 399);
            label4.Name = "label4";
            label4.Size = new Size(86, 25);
            label4.TabIndex = 13;
            label4.Text = "Mật khẩu";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(551, 482);
            label5.Name = "label5";
            label5.Size = new Size(156, 25);
            label5.TabIndex = 16;
            label5.Text = "Nhập lại mật khẩu";
            // 
            // tbRePassword
            // 
            tbRePassword.Location = new Point(547, 512);
            tbRePassword.Margin = new Padding(3, 5, 3, 5);
            tbRePassword.Name = "tbRePassword";
            tbRePassword.Size = new Size(388, 31);
            tbRePassword.TabIndex = 15;
            tbRePassword.UseSystemPasswordChar = true;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(469, 502);
            pictureBox5.Margin = new Padding(3, 5, 3, 5);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(38, 44);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 14;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(471, 419);
            pictureBox4.Margin = new Padding(3, 5, 3, 5);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(38, 44);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 11;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(471, 336);
            pictureBox3.Margin = new Padding(3, 5, 3, 5);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(38, 48);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(471, 248);
            pictureBox2.Margin = new Padding(3, 5, 3, 5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(38, 48);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // btn1
            // 
            btn1.BackColor = Color.White;
            btn1.FlatAppearance.BorderSize = 0;
            btn1.FlatStyle = FlatStyle.Flat;
            btn1.Image = Properties.Resources.hidden;
            btn1.Location = new Point(943, 428);
            btn1.Margin = new Padding(3, 4, 3, 4);
            btn1.Name = "btn1";
            btn1.Size = new Size(47, 32);
            btn1.TabIndex = 19;
            btn1.UseVisualStyleBackColor = false;
            btn1.Click += btn1_Click;
            // 
            // btn2
            // 
            btn2.BackColor = Color.White;
            btn2.FlatAppearance.BorderSize = 0;
            btn2.FlatStyle = FlatStyle.Flat;
            btn2.Image = Properties.Resources.hidden;
            btn2.Location = new Point(943, 512);
            btn2.Margin = new Padding(3, 4, 3, 4);
            btn2.Name = "btn2";
            btn2.Size = new Size(47, 32);
            btn2.TabIndex = 20;
            btn2.UseVisualStyleBackColor = false;
            btn2.Click += btn2_Click;
            // 
            // FResetPassword
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 702);
            Controls.Add(btn2);
            Controls.Add(btn1);
            Controls.Add(label5);
            Controls.Add(tbRePassword);
            Controls.Add(pictureBox5);
            Controls.Add(label4);
            Controls.Add(tbPassword);
            Controls.Add(pictureBox4);
            Controls.Add(label3);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnChangePassword);
            Controls.Add(llbLogin);
            Controls.Add(tbGmail);
            Controls.Add(tbID);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Margin = new Padding(3, 5, 3, 5);
            Name = "FResetPassword";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quên mật khẩu?";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.LinkLabel llbLogin;
        private System.Windows.Forms.TextBox tbGmail;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbRePassword;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
    }
}

