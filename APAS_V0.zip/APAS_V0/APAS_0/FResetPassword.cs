﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APAS_0
{
    public partial class FResetPassword : Form
    {
        public FResetPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FOTP otp = new FOTP();
            this.Hide();
            otp.ShowDialog();
            this.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FLoginForm loginForm = new FLoginForm();
            this.Hide();
            loginForm.ShowDialog();
            this.Show();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (tbPassword.UseSystemPasswordChar == false)
            {
                tbPassword.UseSystemPasswordChar = true;
                btn1.Image = Properties.Resources.hidden;
            }
            else
            {
                tbPassword.UseSystemPasswordChar = false;
                btn1.Image = Properties.Resources.eye;
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (tbRePassword.UseSystemPasswordChar == false)
            {
                tbRePassword.UseSystemPasswordChar = true;
                btn2.Image = Properties.Resources.hidden;
            }
            else
            {
                tbRePassword.UseSystemPasswordChar = false;
                btn2.Image = Properties.Resources.eye;
            }
        }
    }
}
