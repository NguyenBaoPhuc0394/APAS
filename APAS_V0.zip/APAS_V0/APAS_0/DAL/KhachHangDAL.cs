﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class KhachHangDAL
    {
        #region Singleton dp
        private static KhachHangDAL instance;
        public static KhachHangDAL Instance
        {
            get
            {
                if (instance == null)
                    instance = new KhachHangDAL();
                return instance;
            }
            set => instance = value;
        }
        private KhachHangDAL() { }
        #endregion

        public bool CheckExistsCustomer(string sdt)
        {
            string query = "SELECT maKH FROM KhachHang WHERE sdt = @sdt";
            SqlConnection conn = Connector.Instance.GetConnection();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                cmd.Parameters.AddWithValue("@sdt", sdt);
                var result = cmd.ExecuteScalar();
                if (result != null)
                    return true;
                conn.Close();
            }
            return false;
        }

        public string GetMaKHFromSDT(string sdt)
        {
            string res = null;
            string query = "SELECT maKH FROM KhachHang WHERE sdt = @sdt";
            SqlConnection conn = Connector.Instance.GetConnection();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                cmd.Parameters.AddWithValue("@sdt", sdt);
                var result = cmd.ExecuteScalar();
                if (result != null)
                    res = result.ToString();
                conn.Close();
            }
            return res;
        }

        public bool InsertKhachHang(string email, string hoTen, string diachi, string sdt) {
            string query = "INSERT INTO KhachHang (email, hoTen, diachi, sdt) VALUES (@Email, @HoTen, @DiaChi, @Sdt)";
            using(SqlConnection conn = Connector.Instance.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@HoTen", hoTen);
                cmd.Parameters.AddWithValue("@DiaChi", diachi);
                cmd.Parameters.AddWithValue("@Sdt", sdt);
                int r = cmd.ExecuteNonQuery();
                conn.Close();
                return r == 1;
            }
        }
    }
}
