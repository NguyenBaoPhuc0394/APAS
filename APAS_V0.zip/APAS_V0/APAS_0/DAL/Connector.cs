﻿using APAS_0.BLL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class Connector
    {
        #region Singleton dp
        private static Connector instance;
        public static Connector Instance
        {
            get
            {
                if (instance == null)
                    instance = new Connector();
                return instance;
            }
            set => instance = value;
        }
        private Connector() { }
        #endregion
        private string connectionStr = "Data Source=RICKCARL-PC\\SQLEXPRESS;Initial Catalog=QLGX;Integrated Security=True;";

        public SqlConnection GetConnection() { 
            return new SqlConnection(connectionStr);
        }
    }
}
