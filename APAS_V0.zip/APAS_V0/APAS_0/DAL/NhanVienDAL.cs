﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class NhanVienDAL
    {
        #region Singleton dp
        private static NhanVienDAL instance;
        public static NhanVienDAL Instance
        {
            get
            {
                if (instance == null)
                    instance = new NhanVienDAL();
                return instance;
            }
            set => instance = value;
        }
        private NhanVienDAL() { }
        #endregion
    }
}
