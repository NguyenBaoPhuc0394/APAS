﻿using APAS_0.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class TaiKhoanDAL
    {
        #region Singleton dp
        private static TaiKhoanDAL instance;
        public static TaiKhoanDAL Instance
        {
            get
            {
                if (instance == null)
                    instance = new TaiKhoanDAL();
                return instance;
            }
            set => instance = value;
        }
        private TaiKhoanDAL() { }
        #endregion

        public bool CheckAccount(string username, string password) {
            string query = "select count(*) from taikhoan where tenTaiKhoan = @username and matkhau = @password";
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);
                int i = Convert.ToInt32(command.ExecuteScalar());
                conn.Close();
                if (i > 0) 
                    return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally { 
                conn.Close();
            }
            return false;
        }

        public NhanVien GetNhanVienFromLoginInfor(string username, string password) {
            string query = "select * from NhanVien where manv in (select manv from taikhoan where tenTaiKhoan = @username and matkhau = @password)";
            SqlConnection conn = Connector.Instance.GetConnection();
            DataTable table = new DataTable();
            NhanVien nv = new NhanVien();
            try
            {
                conn.Open();
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@username", username);
                command.Parameters.AddWithValue("@password", password);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(table);
                foreach (DataRow row in table.Rows) { 
                    nv = new NhanVien(row);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            return nv;
        }
    }
}
