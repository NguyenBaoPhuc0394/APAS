﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class DichVuDAL
    {
        #region Singleton dp
        private static DichVuDAL instance;
        public static DichVuDAL Instance
        {
            get
            {
                if (instance == null)
                    instance = new DichVuDAL();
                return instance;
            }
            set => instance = value;
        }
        private DichVuDAL() { }
        #endregion

        public bool InsertService(string maDV, string maPT, string maNV, DateTime ngayDangKy, DateTime ngayHetHan, string hinhAnh)
        {
            bool conThoiHan = DateTime.Now <= ngayHetHan;
            string query = "INSERT INTO DichVu (maDV, maPT, maNV, ngayDangKy, ngayHetHan, hinhAnh, conThoiHan) " +
                       "VALUES (@maDV, @maPT, @maNV, @NgayDangKy, @NgayHetHan, @HinhAnh, @ConThoiHan)";
            using(SqlConnection conn = Connector.Instance.GetConnection())
            {
                conn.Open();
                SqlCommand insertCmd = new SqlCommand(query, conn);
                insertCmd.Parameters.AddWithValue("@MaDV", maDV);
                insertCmd.Parameters.AddWithValue("@MaPT", maPT);
                insertCmd.Parameters.AddWithValue("@MaNV", maNV);
                insertCmd.Parameters.AddWithValue("@NgayDangKy", ngayDangKy);
                insertCmd.Parameters.AddWithValue("@NgayHetHan", ngayHetHan);
                insertCmd.Parameters.AddWithValue("@HinhAnh", hinhAnh);
                insertCmd.Parameters.AddWithValue("@ConThoiHan", conThoiHan); // Thêm giá trị của conThoiHan vào truy vấn

                int r = insertCmd.ExecuteNonQuery();
                conn.Close();
                return r > 0;
            }
        }

        public string GetHinhAnhFromBSX(string bsx)
        {
            string query = "select hinhanh from DichVu where maPT in (select maPT from PhuongTien where bienSoXe = @bsx)";
            using (SqlConnection conn = Connector.Instance.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@bsx", bsx);

                var r = cmd.ExecuteScalar();
                conn.Close();
                if (r == null) return "";
                return r.ToString();
            }
        }

        public DataTable GetDataServices()
        {
            DataTable dt = new DataTable();
            string query = "SELECT DichVu.maDV,KhachHang.hoTen,KhachHang.sdt,PhuongTien.bienSoXe,PhuongTien.loaiPT,DichVu.ngayDangKy,DichVu.ngayHetHan,DichVu.hinhAnh,DichVu.conThoiHan FROM DichVu INNER JOIN PhuongTien ON DichVu.maPT = PhuongTien.maPT INNER JOIN KhachHang ON PhuongTien.maKH = KhachHang.maKH";
            using (SqlConnection conn = Connector.Instance.GetConnection())
            {
                conn.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.Fill(dt);
                conn.Close();
            }
            return dt;
        }
    }
}
