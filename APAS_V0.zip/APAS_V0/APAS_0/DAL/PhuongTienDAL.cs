﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class PhuongTienDAL
    {
        #region Singleton dp
        private static PhuongTienDAL instance;
        public static PhuongTienDAL Instance
        {
            get
            {
                if (instance == null)
                    instance = new PhuongTienDAL();
                return instance;
            }
            set => instance = value;
        }
        private PhuongTienDAL() { }
        #endregion

        public bool CheckExistsPhuongTien(string bienSoXe)
        {
            string query = "SELECT maPT FROM PhuongTien WHERE bienSoXe = @bienSoXe";
            SqlConnection conn = Connector.Instance.GetConnection();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                cmd.Parameters.AddWithValue("@bienSoXe", bienSoXe);
                var result = cmd.ExecuteScalar();
                if (result != null)
                    return true;
                conn.Close();
            }
            return false;
        }

        public string GetMaPTFromBSX(string bienSoXe)
        {
            string res = null;
            string query = "SELECT maPT FROM PhuongTien WHERE bienSoXe = @bienSoXe";
            SqlConnection conn = Connector.Instance.GetConnection();
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                conn.Open();
                cmd.Parameters.AddWithValue("@bienSoXe", bienSoXe);
                var result = cmd.ExecuteScalar();
                if (result != null)
                    res = result.ToString();
                conn.Close();
            }
            return res.ToString();
        }

        public bool InsertPhuongTien(string maKH, string loaiPT, string bienSoXe, string mauPT, bool xeDien, string hangPT)
        {
            string query = "INSERT INTO PhuongTien (maKH, bienSoXe, loaiPT, mauPT, xeDien, hangPT) " +
                        "VALUES (@maKH, @BienSoXe, @LoaiPT, @MauPT, @XeDien, @HangPT)";
            using (SqlConnection conn = Connector.Instance.GetConnection())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@maKH", maKH);
                cmd.Parameters.AddWithValue("@loaiPT", loaiPT);
                cmd.Parameters.AddWithValue("@bienSoXe", bienSoXe);
                cmd.Parameters.AddWithValue("@mauPT", mauPT);
                cmd.Parameters.AddWithValue("@xeDien", xeDien);
                cmd.Parameters.AddWithValue("@hangPT", hangPT);
                int r = cmd.ExecuteNonQuery();
                conn.Close();
                return r == 1;
            }
        }
    }
}
