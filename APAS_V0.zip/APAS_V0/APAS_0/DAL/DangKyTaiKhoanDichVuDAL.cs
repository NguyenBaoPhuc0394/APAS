﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.DAL
{
    public class DangKyTaiKhoanDichVuDAL
    {
        #region Singleton dp
        private static DangKyTaiKhoanDichVuDAL instance;

        public static DangKyTaiKhoanDichVuDAL Instance { 
            get
            {
                if(instance == null)
                    instance = new DangKyTaiKhoanDichVuDAL();
                return instance;
            }
            set => instance = value; }

        private DangKyTaiKhoanDichVuDAL() { }
        #endregion

        private void insertRegisterData(string name, string email, string phoneNumber, string address, string motorNumber, string motorColor
            , string motorBrand, string motorFuel, string carNumber, string carColor, string carBrand, string carFuel, string bicycle)
        {
            int bicycleValue = 0;
            if (bicycle.Contains('C')) bicycleValue = 1;
            SqlConnection conn = Connector.Instance.GetConnection();
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("InsertYeuCauDangKy", conn))
            {
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@hoTen", name);
                cmd.Parameters.AddWithValue("@email", email);
                cmd.Parameters.AddWithValue("@sdt", phoneNumber);
                cmd.Parameters.AddWithValue("@diachi", address);
                cmd.Parameters.AddWithValue("@bienSoXM", motorNumber);
                cmd.Parameters.AddWithValue("@mauSacXM", motorColor);
                cmd.Parameters.AddWithValue("@hangXM", motorBrand);
                cmd.Parameters.AddWithValue("@nhienLieuXM", motorFuel);
                cmd.Parameters.AddWithValue("@bienSoOT", carNumber);
                cmd.Parameters.AddWithValue("@mauSacOT", carColor);
                cmd.Parameters.AddWithValue("@hangOT", carBrand);
                cmd.Parameters.AddWithValue("@nhienLieuOT", carFuel);
                cmd.Parameters.AddWithValue("@guiXeDap", bicycleValue);
                cmd.ExecuteNonQuery();
            }
            conn.Close();
        }

        //public void getRegisterData()
        //{
        //    string[] scopes = { SheetsService.Scope.Spreadsheets };
        //    UserCredential credential = GoogleAuthentication.Login("776126185891-6s0r8u592b0d02d4faajtvjeb1vjqtrt.apps.googleusercontent.com", "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", scopes);
        //    GoogleSheetManager sheetManager = new GoogleSheetManager(credential);

        //    string sheetID = "1CWq3nsC_gCmDEUKZATc0KqhSXxQnhwNbz02D4JxHLGU";
        //    var spreadSheet = sheetManager.GetSpreadsheet(sheetID);
        //    string[] range = new[] { "B2:N100" };
        //    var response = sheetManager.GetMultipleValue(sheetID, range);
        //    var result = response.ValueRanges[0];
        //    if (result.Values == null || result.Values.Count == 0) return;
        //    for (int i = 0; i < result.Values.Count; i++)
        //    {
        //        var row = result.Values[i];
        //        if (row.Count >= 13)
        //        {
        //            string name = row[0].ToString();
        //            string email = row[1].ToString();
        //            string phoneNumber = row[2].ToString();
        //            string address = row[3].ToString();
        //            string motorNumber = row[4].ToString();
        //            string motorColor = row[5].ToString();
        //            string motorBrand = row[6].ToString();
        //            string motorFuel = row[7].ToString();
        //            string carNumber = row[8].ToString();
        //            string carColor = row[9].ToString();
        //            string carBrand = row[10].ToString();
        //            string carFuel = row[11].ToString();
        //            string bicycle = row[12].ToString();

        //            insertRegisterData(name, email, phoneNumber, address, motorNumber, motorColor,
        //                               motorBrand, motorFuel, carNumber, carColor, carBrand, carFuel, bicycle);
        //        }
        //    }
        //    conn.Close();
        //    string[] deleteRange = new[] { "A2:N100" };
        //    sheetManager.clearMultipleValues(sheetID, deleteRange);
        //}

        public void getRegisterData()
        {
            string[] scopes = { SheetsService.Scope.Spreadsheets };
            string serviceAccountKeyFilePath = "credential.json";
            GoogleCredential credential;
            using (var stream = new FileStream(serviceAccountKeyFilePath, FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream).CreateScoped(scopes);
            }
            var sheetService = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "Your Application Name",
            });
            string sheetID = "1CWq3nsC_gCmDEUKZATc0KqhSXxQnhwNbz02D4JxHLGU";
            string range = "B2:N100";
            var request = sheetService.Spreadsheets.Values.Get(sheetID, range);
            ValueRange response = request.Execute();
            var values = response.Values;
            if (values == null || values.Count == 0)
            {
                Console.WriteLine("No data found.");
                return;
            }
            foreach (var row in values)
            {
                if (row.Count >= 13)
                {
                    string name = row[0]?.ToString() ?? "";
                    string email = row[1]?.ToString() ?? "";
                    string phoneNumber = row[2]?.ToString() ?? "";
                    string address = row[3]?.ToString() ?? "";
                    string motorNumber = row[4]?.ToString() ?? "";
                    string motorColor = row[5]?.ToString() ?? "";
                    string motorBrand = row[6]?.ToString() ?? "";
                    string motorFuel = row[7]?.ToString() ?? "";
                    string carNumber = row[8]?.ToString() ?? "";
                    string carColor = row[9]?.ToString() ?? "";
                    string carBrand = row[10]?.ToString() ?? "";
                    string carFuel = row[11]?.ToString() ?? "";
                    string bicycle = row[12]?.ToString() ?? "";
                }
            }
            var clearRequest = new ClearValuesRequest();
            var deleteRequest = sheetService.Spreadsheets.Values.Clear(clearRequest, sheetID, range);
            deleteRequest.Execute();
        }

        public static DataTable getRegisterRequests()
        {
            DataTable dataTable = new DataTable();
            SqlConnection conn = Connector.Instance.GetConnection();
            string query = "SELECT top 10 maYeuCau, hoTen, email, sdt FROM DangKyTaiKhoanDichVu where tinhTrang = 0";
            try
            {

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(dataTable);
                    }
                    conn.Close();
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return dataTable;
        }

        public static LinkedList<string> getRegisterRequestData(string requestID)
        {
            string query = "SELECT * FROM DangKyTaiKhoanDichVu WHERE maYeuCau = @requestID";
            LinkedList<string> data = new LinkedList<string>();
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    cmd.Parameters.AddWithValue("@requestID", requestID);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                data.AddLast(reader[i].ToString());
                            }
                        }
                    }
                    conn.Close();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return data;
        }

        public static bool checkExistPhoneNumber(string phoneNumber)
        {
            string query = "SELECT COUNT(1) FROM TaiKhoanDichVu WHERE tenDangNhap = @phoneNumber";
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@phoneNumber", phoneNumber);
                    conn.Open();

                    int count = (int)cmd.ExecuteScalar();
                    conn.Close();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool checkExistEmail(string email)
        {
            string query = "SELECT COUNT(1) FROM TaiKhoanDichVu WHERE email = @email";
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@email", email);
                    conn.Open();

                    int count = (int)cmd.ExecuteScalar();
                    conn.Close();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool checkExistVehicle(string vehicleNumber)
        {
            string query = "SELECT COUNT(1) FROM PhuongTien WHERE soXe = @soXe";
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@soXe", vehicleNumber);
                    conn.Open();

                    int count = (int)cmd.ExecuteScalar();
                    conn.Close();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool UpdateRegisterRequestStatus(string requestID)
        {
            string query = "UPDATE DangKyTaiKhoanDichVu SET tinhTrang = 1 where maYeuCau = @maYeuCau";
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@maYeuCau", requestID);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static List<string> getAreaDataForCombobox(string[] data)
        {
            string query = "SELECT maKhuVuc FROM KhuVuc WHERE loaiXe = @loaiXe AND soChoKhaDung > 0";
            int n;
            if (string.IsNullOrEmpty(data[0])) return new List<string>();

            if (data[0] == "M" && data[1] == "g") n = 0;
            else if (data[0] == "M" && data[1] == "e") n = 1;
            else if (data[0] == "C" && data[1] == "g") n = 2;
            else n = 3;
            SqlConnection conn = Connector.Instance.GetConnection();
            List<string> availableLocations = new List<string>();

            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@loaiXe", n);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            availableLocations.Add(reader["maKhuVuc"].ToString());
                        }
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return availableLocations;
        }

        public static bool checkAreaForBicycle()
        {
            string query = "SELECT COUNT(*) FROM KhuVuc WHERE loaiXe = 4 AND soChoKhaDung > 0";
            SqlConnection conn = Connector.Instance.GetConnection();
            try
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    int availableCount = (int)cmd.ExecuteScalar();
                    conn.Close();

                    return availableCount > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool register(string tenDangNhap, string password, string email)
        {
            string encryptedPassword;
            int result;
            using (MD5 md5 = MD5.Create())
            {
                encryptedPassword = GetMd5Hash(md5, password);
            }
            SqlConnection conn = Connector.Instance.GetConnection();
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("InsertTaiKhoanDichVu", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@TenDangNhap", tenDangNhap));
                cmd.Parameters.Add(new SqlParameter("@hashPassword", encryptedPassword));
                cmd.Parameters.Add(new SqlParameter("@Email", email));
                result = cmd.ExecuteNonQuery();
            }
            conn.Close();
            return result > 0;
        }

        private static string GetMd5Hash(MD5 md5Hash, string input)
        {
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder sBuilder = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }
            return sBuilder.ToString();
        }

        public static bool InsertVehicle(string number, string owner, string area, string color, string brand, int type)
        {
            int result;
            SqlConnection conn = Connector.Instance.GetConnection();
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("InsertPhuongTien", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@soXe", number));
                cmd.Parameters.Add(new SqlParameter("@tenDangNhap", owner));
                cmd.Parameters.Add(new SqlParameter("@maKhuVuc", area));
                cmd.Parameters.Add(new SqlParameter("@mauSac", color));
                cmd.Parameters.Add(new SqlParameter("@hangXe", brand));
                cmd.Parameters.Add(new SqlParameter("@loaiXe", type));
                result = cmd.ExecuteNonQuery();
            }
            conn.Close();
            return result > 0;
        }

        public static bool insertBicycle(string owner)
        {
            int result;
            SqlConnection conn = Connector.Instance.GetConnection();
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("InsertQuanLyXeDap", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@taiKhoanSoHuu", owner));

                result = cmd.ExecuteNonQuery();
            }
            conn.Close();
            return result > 0;
        }
    }
}
