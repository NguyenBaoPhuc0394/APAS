﻿using APAS_0.Controls;
using APAS_0.DAL;
using APAS_0.DTO;
using Google.Apis.Sheets.v4.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APAS_0
{
    public partial class UCDangKyDichVu : UserControl
    {
        private NhanVien nhanvien;
        private DataTable dt;
        private string sheetID = "1wjRs33cMLQspwFGhrmIR8hMyWqoJjc_0Ty1NGl1Kyw0";
        public NhanVien Nhanvien { get => nhanvien; set => nhanvien = value; }
        public DataTable Dt { get => dt; set => dt = value; }
        public UCDangKyDichVu(NhanVien nv)
        {
            InitializeComponent();
            Nhanvien = nv;
        }

        private void FQuanLyDangKyDichVu_Load(object sender, EventArgs e)
        {
            dt = getRegisterData();
            dtgv_list.DataSource = dt;
            tbStaff.Text = Nhanvien.TenNV;
            SetEditingMode(true);
        }

        public string getEmail()
        {
            return tbEmail.Text;
        }

        public string getPhoneNumber()
        {
            return tbSdt.Text;
        }

        private void SetEditingMode(bool enable)
        {
            tbExpiration.Enabled = !enable;
            tbBrand.Enabled = !enable;
            tbName.Enabled = !enable;
            tbEmail.Enabled = !enable;
            tbColor.Enabled = !enable;
            tbLicensePlate.Enabled = !enable;
            tbRegistration.Enabled = !enable;
            tbAddress.Enabled = !enable;
            tbSdt.Enabled = !enable;
            tbType.Enabled = !enable;
            cbElec.Enabled = !enable;
            btnAccept.Enabled = !enable;
            btnInfor.Enabled = !enable;
            btnRemove.Enabled = !enable;
            dtpkUpdate.Enabled = !enable;
            //btnNotify.Enabled = !enable;
        }

        private void Reset()
        {
            tbExpiration.Text = "";
            tbBrand.Text = "";
            tbName.Text = "";
            tbEmail.Text = "";
            tbColor.Text = "";
            tbLicensePlate.Text = "";
            tbRegistration.Text = "";
            tbAddress.Text = "";
            tbSdt.Text = "";
            tbType.Text = "";
            cbElec.Checked = false;
            btnAccept.Enabled = false;
            btnInfor.Enabled = false;
            btnRemove.Enabled = false;
            dtpkUpdate.Enabled = false;
        }
        private DataTable getRegisterData()
        {
            var sheetService = GGSheetsService.Instance.GetServices();
            string range = "Sheet1!A1:J";
            var request = sheetService.Spreadsheets.Values.Get(sheetID, range);
            ValueRange response = request.Execute();
            var values = response.Values;
            if (values == null || values.Count == 0)
            {
                Console.WriteLine("No data found.");
                return new DataTable();
            }
            DataTable dataTable = new DataTable();
            //foreach (var header in values[0])
            //{
            //    dataTable.Columns.Add(header.ToString());
            //}
            dataTable.Columns.Add("Họ tên");
            dataTable.Columns.Add("Email");
            dataTable.Columns.Add("Thời gian đăng ký");
            dataTable.Columns.Add("Số điện thoại");
            dataTable.Columns.Add("Địa chỉ");
            dataTable.Columns.Add("Loại phương tiện");
            dataTable.Columns.Add("Có phải xe điện không?");
            dataTable.Columns.Add("Biển số xe");
            dataTable.Columns.Add("Màu xe");
            dataTable.Columns.Add("Loại hãng xe");

            for (int i = 1; i < values.Count; i++)
            {
                DataRow row = dataTable.NewRow();
                //for (int j = 0; j < values[i].Count; j++)
                //{
                //    row[j] = values[i][j];
                //}
                row["Họ tên"] = values[i][2];
                row["Email"] = values[i][1];
                row["Thời gian đăng ký"] = values[i][0];
                row["Số điện thoại"] = values[i][3];
                row["Địa chỉ"] = values[i][4];
                row["Loại phương tiện"] = values[i][6];
                row["Có phải xe điện không?"] = values[i][5];
                row["Biển số xe"] = (values[i].Count > 7 && values[i][7] != null) ? values[i][7] : "";
                row["Màu xe"] = (values[i].Count > 8 && values[i][8] != null) ? values[i][8] : "";
                row["Loại hãng xe"] = (values[i].Count > 9 && values[i][9] != null) ? values[i][9] : "";


                dataTable.Rows.Add(row);
            }
            return dataTable;
        }

        private void DeleteRowFromGoogleSheets(string sheetName, int rowToDelete)
        {
            var deleteRequest = new BatchUpdateSpreadsheetRequest
            {
                Requests = new List<Request>
                {
                    new Request
                    {
                        DeleteDimension = new DeleteDimensionRequest
                        {
                            Range = new DimensionRange
                            {
                                SheetId = GGSheetsService.Instance.GetSheetId(sheetID, sheetName),
                                Dimension = "ROWS",
                                StartIndex = rowToDelete - 1,
                                EndIndex = rowToDelete
                            }
                        }
                    }
                }
            };
            var service = GGSheetsService.Instance.GetServices();

            var batchUpdateRequest = service.Spreadsheets.BatchUpdate(deleteRequest, sheetID);
            batchUpdateRequest.Execute();
        }
        private void dtgv_list_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SetEditingMode(false);

            int index = dtgv_list.SelectedCells[0].RowIndex;
            DataGridViewRow row = dtgv_list.Rows[index];
            if (index < 0 || index >= dtgv_list.RowCount)
            {
                return;
            }
            string date = row.Cells[2].Value.ToString().Split(" ")[0];

            tbName.Text = row.Cells[0].Value.ToString();
            tbEmail.Text = row.Cells[1].Value.ToString();
            tbRegistration.Text = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
            tbExpiration.Text = getNextMonth(date);
            tbSdt.Text = row.Cells[3].Value.ToString();
            tbAddress.Text = row.Cells[4].Value.ToString();
            tbType.Text = row.Cells[5].Value.ToString();
            if (row.Cells[6].Value.ToString() == "CÓ")
                cbElec.Checked = true;
            tbLicensePlate.Text = row.Cells[7].Value.ToString();

            tbColor.Text = row.Cells[8].Value.ToString();
            tbBrand.Text = row.Cells[9].Value.ToString();
        }
        private string getNextMonth(string month)
        {
            string[] times = month.Split("/");
            DateTime dateTime = new DateTime(Convert.ToInt32(times[2]), Convert.ToInt32(times[1]), Convert.ToInt32(times[0]));
            DateTime nextMonth = dateTime.AddMonths(1);
            return nextMonth.ToString("dd/MM/yyyy");
        }
        public bool RegisterService(string maNV, string hoTen, string sdt, string email, string loaiPT, string mauPT,
                                string bienSoXe, string diaChi, string hangPT, DateTime ngayDangKy,
                                DateTime ngayHetHan, bool xeDien, string hinhAnhPath)
        {
            bool isExistsKH = KhachHangDAL.Instance.CheckExistsCustomer(sdt);
            string maDV = GenerateServiceCode(loaiPT, xeDien);
            string maKH = "";
            string maPT = "";
            if (isExistsKH)
            {
                maKH = KhachHangDAL.Instance.GetMaKHFromSDT(sdt);
            }
            else
            {
                KhachHangDAL.Instance.InsertKhachHang(email, hoTen, diaChi, sdt);
                maKH = KhachHangDAL.Instance.GetMaKHFromSDT(sdt);
            }
            bool isExistsPT = PhuongTienDAL.Instance.CheckExistsPhuongTien(bienSoXe);
            if (isExistsPT)
            {
                maPT = PhuongTienDAL.Instance.GetMaPTFromBSX(bienSoXe);
            }
            else
            {
                if (maKH != "")
                    PhuongTienDAL.Instance.InsertPhuongTien(maKH, loaiPT, bienSoXe, mauPT, xeDien, hangPT);
                maPT = PhuongTienDAL.Instance.GetMaPTFromBSX(bienSoXe);
            }
            if (maDV != null && maPT != null)
            {
                bool res = DichVuDAL.Instance.InsertService(maDV, maPT, maNV, ngayDangKy, ngayHetHan, hinhAnhPath);
                return res;
            }
            return false;
        }
        private string GenerateServiceCode(string loaiPT, bool xeDien)
        {
            char loai = loaiPT.ToLower() switch
            {
                "xe đạp" => 'B',
                "xe máy" => 'M',
                "xe hơi" => 'C',
                _ => 'X'
            };
            char dien = xeDien ? 'E' : 'N';
            string randomPart = Guid.NewGuid().ToString().Substring(0, 6).ToUpper();
            return $"{loai}{dien}{randomPart}";
        }
        private void btnInfor_Click(object sender, EventArgs e)
        {
            if (dtgv_list.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dtgv_list.SelectedRows[0];
                //int index = dtgv_list.SelectedCells[0].RowIndex;
                //DataGridViewRow row = dtgv_list.Rows[index];
                string hoTen = tbName.Text;
                string sdt = tbSdt.Text;
                string ngayDK = tbRegistration.Text;
                string ngayHH = tbExpiration.Text;
                string staff = tbStaff.Text;
                string bsx = tbLicensePlate.Text;
                string hinhanh = lbHinhanh.Text;
                FHinhAnh fha = new FHinhAnh(hoTen, sdt, ngayDK, ngayHH, staff, bsx, hinhanh);
                if (fha.ShowDialog() == DialogResult.OK)
                {
                    lbHinhanh.Text = fha.Hinhanh;
                }
            }
        }
        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (dtgv_list.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dtgv_list.SelectedRows[0];
                int selectedIndex = selectedRow.Index;
                string name = tbName.Text;
                string email = tbEmail.Text;
                string sdt = tbSdt.Text;
                DateTime ngayDK = DateTime.ParseExact(tbRegistration.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture); ;
                DateTime ngayHH = DateTime.ParseExact(tbExpiration.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture); ;
                string staff = tbStaff.Text;
                string color = tbColor.Text;
                string brand = tbBrand.Text;
                bool xeDien = cbElec.Checked;
                string hinhanh = lbHinhanh.Text;
                string bsx = tbLicensePlate.Text;
                string address = tbAddress.Text;
                string type = tbType.Text;

                bool res = RegisterService(Nhanvien.MaNV, name, sdt, email, type, color, bsx, address, brand, ngayDK, ngayHH, xeDien, hinhanh);
                if (res == true)
                {
                    deleteRow(selectedIndex);
                    MessageBox.Show("Đăng ký dịch vụ thành công!", "Thông báo", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("Đăng ký dịch vụ thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void deleteRow(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= dt.Rows.Count)
            {
                MessageBox.Show("Chỉ số dòng không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dt.Rows.RemoveAt(rowIndex);
            DeleteRowFromGoogleSheets("Sheet1", rowIndex + 2);
            dtgv_list.DataSource = null;
            dt = getRegisterData();
            dtgv_list.DataSource = dt;

            Reset();
        }
        private void dtgv_list_SelectionChanged(object sender, EventArgs e)
        {
            if (dtgv_list.SelectedRows.Count > 0)
            {
                btnInfor.Enabled = true;
            }
            else
            {
                btnInfor.Enabled = false;
            }
        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dtgv_list.SelectedRows[0];
            int selectedIndex = selectedRow.Index;
            deleteRow(selectedIndex);
        }
        private void btnServices_Click(object sender, EventArgs e)
        {
            FQuanLyDichVu f = new FQuanLyDichVu(Nhanvien);
            f.ShowDialog();
        }

        private void btnNotify_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = dtgv_list.SelectedRows[0];
            int selectedIndex = selectedRow.Index;
            FMain f = new FMain(Nhanvien);
            FPhanHoiKhachHang form = new FPhanHoiKhachHang(f);
            form.ShowDialog();
        }

        private void lbHinhanh_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(lbHinhanh.Text) && lbHinhanh.Text == "")
            {
                btnAccept.Enabled = false;
            }
            else
            {
                btnAccept.Enabled = true;
            }
        }
    }
}
