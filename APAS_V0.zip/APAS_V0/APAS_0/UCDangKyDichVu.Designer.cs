﻿namespace APAS_0
{
    partial class UCDangKyDichVu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelControl2 = new Controls.PanelControl();
            label3 = new Label();
            tbName = new TextBox();
            cbElec = new CheckBox();
            tbType = new TextBox();
            tbColor = new TextBox();
            label14 = new Label();
            tbEmail = new TextBox();
            tbLicensePlate = new TextBox();
            tbExpiration = new TextBox();
            tbSdt = new TextBox();
            tbAddress = new TextBox();
            label12 = new Label();
            label4 = new Label();
            label6 = new Label();
            tbRegistration = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label11 = new Label();
            label9 = new Label();
            label10 = new Label();
            tbBrand = new TextBox();
            label13 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnRemove = new Controls.Buttons();
            label5 = new Label();
            btnAccept = new Controls.Buttons();
            btnInfor = new Controls.Buttons();
            lbHinhanh = new Label();
            tbStaff = new TextBox();
            label17 = new Label();
            dtpkUpdate = new DateTimePicker();
            label16 = new Label();
            panel3 = new Panel();
            dtgv_list = new DataGridView();
            panelControl2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgv_list).BeginInit();
            SuspendLayout();
            // 
            // panelControl2
            // 
            panelControl2.BackColor = Color.FromArgb(69, 197, 149);
            panelControl2.BorderRadius = 50;
            panelControl2.Controls.Add(label3);
            panelControl2.Controls.Add(tbName);
            panelControl2.Controls.Add(cbElec);
            panelControl2.Controls.Add(tbType);
            panelControl2.Controls.Add(tbColor);
            panelControl2.Controls.Add(label14);
            panelControl2.Controls.Add(tbEmail);
            panelControl2.Controls.Add(tbLicensePlate);
            panelControl2.Controls.Add(tbExpiration);
            panelControl2.Controls.Add(tbSdt);
            panelControl2.Controls.Add(tbAddress);
            panelControl2.Controls.Add(label12);
            panelControl2.Controls.Add(label4);
            panelControl2.Controls.Add(label6);
            panelControl2.Controls.Add(tbRegistration);
            panelControl2.Controls.Add(label7);
            panelControl2.Controls.Add(label8);
            panelControl2.Controls.Add(label11);
            panelControl2.Controls.Add(label9);
            panelControl2.Controls.Add(label10);
            panelControl2.Controls.Add(tbBrand);
            panelControl2.Controls.Add(label13);
            panelControl2.Location = new Point(3, 46);
            panelControl2.Name = "panelControl2";
            panelControl2.Size = new Size(318, 520);
            panelControl2.TabIndex = 34;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(111, 31);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 30;
            label3.Text = "Thông tin";
            // 
            // tbName
            // 
            tbName.Location = new Point(94, 76);
            tbName.Name = "tbName";
            tbName.Size = new Size(204, 23);
            tbName.TabIndex = 1;
            // 
            // cbElec
            // 
            cbElec.AutoSize = true;
            cbElec.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cbElec.Location = new Point(94, 480);
            cbElec.Margin = new Padding(2);
            cbElec.Name = "cbElec";
            cbElec.Size = new Size(70, 19);
            cbElec.TabIndex = 29;
            cbElec.Text = "Xe Điện";
            cbElec.UseVisualStyleBackColor = true;
            // 
            // tbType
            // 
            tbType.Location = new Point(94, 196);
            tbType.Name = "tbType";
            tbType.Size = new Size(204, 23);
            tbType.TabIndex = 4;
            // 
            // tbColor
            // 
            tbColor.Location = new Point(94, 236);
            tbColor.Name = "tbColor";
            tbColor.Size = new Size(204, 23);
            tbColor.TabIndex = 5;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 9F);
            label14.Location = new Point(10, 440);
            label14.Name = "label14";
            label14.Size = new Size(79, 15);
            label14.TabIndex = 27;
            label14.Text = "Ngày hết hạn";
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(94, 156);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(204, 23);
            tbEmail.TabIndex = 3;
            // 
            // tbLicensePlate
            // 
            tbLicensePlate.Location = new Point(94, 276);
            tbLicensePlate.Name = "tbLicensePlate";
            tbLicensePlate.Size = new Size(204, 23);
            tbLicensePlate.TabIndex = 6;
            // 
            // tbExpiration
            // 
            tbExpiration.Location = new Point(94, 436);
            tbExpiration.Name = "tbExpiration";
            tbExpiration.Size = new Size(204, 23);
            tbExpiration.TabIndex = 26;
            // 
            // tbSdt
            // 
            tbSdt.Location = new Point(94, 116);
            tbSdt.Name = "tbSdt";
            tbSdt.Size = new Size(204, 23);
            tbSdt.TabIndex = 2;
            // 
            // tbAddress
            // 
            tbAddress.Location = new Point(94, 316);
            tbAddress.Name = "tbAddress";
            tbAddress.Size = new Size(204, 23);
            tbAddress.TabIndex = 8;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 9F);
            label12.Location = new Point(9, 400);
            label12.Name = "label12";
            label12.Size = new Size(80, 15);
            label12.TabIndex = 25;
            label12.Text = "Ngày đăng ký";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F);
            label4.Location = new Point(27, 80);
            label4.Name = "label4";
            label4.Size = new Size(62, 15);
            label4.TabIndex = 12;
            label4.Text = "Họ và Tên";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9F);
            label6.Location = new Point(58, 120);
            label6.Name = "label6";
            label6.Size = new Size(31, 15);
            label6.TabIndex = 13;
            label6.Text = "SĐT";
            // 
            // tbRegistration
            // 
            tbRegistration.Location = new Point(94, 396);
            tbRegistration.Name = "tbRegistration";
            tbRegistration.Size = new Size(204, 23);
            tbRegistration.TabIndex = 24;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9F);
            label7.Location = new Point(50, 160);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 14;
            label7.Text = "Email";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F);
            label8.Location = new Point(42, 200);
            label8.Name = "label8";
            label8.Size = new Size(47, 15);
            label8.TabIndex = 15;
            label8.Text = "Loại xe";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 9F);
            label11.Location = new Point(11, 360);
            label11.Name = "label11";
            label11.Size = new Size(78, 15);
            label11.TabIndex = 23;
            label11.Text = "Loại hãng xe";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9F);
            label9.Location = new Point(41, 240);
            label9.Name = "label9";
            label9.Size = new Size(48, 15);
            label9.TabIndex = 16;
            label9.Text = "Màu xe";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 9F);
            label10.Location = new Point(25, 280);
            label10.Name = "label10";
            label10.Size = new Size(64, 15);
            label10.TabIndex = 17;
            label10.Text = "Biển số xe";
            // 
            // tbBrand
            // 
            tbBrand.Location = new Point(94, 356);
            tbBrand.Name = "tbBrand";
            tbBrand.Size = new Size(204, 23);
            tbBrand.TabIndex = 22;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 9F);
            label13.Location = new Point(44, 320);
            label13.Name = "label13";
            label13.Size = new Size(45, 15);
            label13.TabIndex = 21;
            label13.Text = "Địa chỉ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(318, -46);
            label2.Name = "label2";
            label2.Size = new Size(195, 24);
            label2.TabIndex = 33;
            label2.Text = "QUẢN LÝ ĐĂNG KÝ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(369, 10);
            label1.Name = "label1";
            label1.Size = new Size(213, 25);
            label1.TabIndex = 35;
            label1.Text = "ĐĂNG KÝ DỊCH VỤ";
            // 
            // btnRemove
            // 
            btnRemove.BackColor = Color.FromArgb(255, 75, 8);
            btnRemove.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnRemove.BorderColor = Color.PaleVioletRed;
            btnRemove.BorderRadius = 20;
            btnRemove.BorderSize = 0;
            btnRemove.FlatAppearance.BorderSize = 0;
            btnRemove.FlatStyle = FlatStyle.Flat;
            btnRemove.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRemove.ForeColor = Color.White;
            btnRemove.Location = new Point(537, 518);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(99, 40);
            btnRemove.TabIndex = 45;
            btnRemove.Text = "Xoá";
            btnRemove.TextColor = Color.White;
            btnRemove.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(335, 49);
            label5.Name = "label5";
            label5.Size = new Size(139, 16);
            label5.TabIndex = 36;
            label5.Text = "Danh sách đăng ký";
            // 
            // btnAccept
            // 
            btnAccept.BackColor = Color.FromArgb(255, 75, 8);
            btnAccept.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnAccept.BorderColor = Color.PaleVioletRed;
            btnAccept.BorderRadius = 20;
            btnAccept.BorderSize = 0;
            btnAccept.FlatAppearance.BorderSize = 0;
            btnAccept.FlatStyle = FlatStyle.Flat;
            btnAccept.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAccept.ForeColor = Color.White;
            btnAccept.Location = new Point(432, 518);
            btnAccept.Name = "btnAccept";
            btnAccept.Size = new Size(99, 40);
            btnAccept.TabIndex = 44;
            btnAccept.Text = "Duyệt";
            btnAccept.TextColor = Color.White;
            btnAccept.UseVisualStyleBackColor = false;
            // 
            // btnInfor
            // 
            btnInfor.BackColor = Color.FromArgb(255, 75, 8);
            btnInfor.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnInfor.BorderColor = Color.PaleVioletRed;
            btnInfor.BorderRadius = 20;
            btnInfor.BorderSize = 0;
            btnInfor.FlatAppearance.BorderSize = 0;
            btnInfor.FlatStyle = FlatStyle.Flat;
            btnInfor.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInfor.ForeColor = Color.White;
            btnInfor.Location = new Point(327, 518);
            btnInfor.Name = "btnInfor";
            btnInfor.Size = new Size(99, 40);
            btnInfor.TabIndex = 38;
            btnInfor.Text = "Hình ảnh";
            btnInfor.TextColor = Color.White;
            btnInfor.UseVisualStyleBackColor = false;
            // 
            // lbHinhanh
            // 
            lbHinhanh.AutoSize = true;
            lbHinhanh.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbHinhanh.Location = new Point(327, 565);
            lbHinhanh.Margin = new Padding(2, 0, 2, 0);
            lbHinhanh.Name = "lbHinhanh";
            lbHinhanh.Size = new Size(0, 13);
            lbHinhanh.TabIndex = 43;
            lbHinhanh.Visible = false;
            // 
            // tbStaff
            // 
            tbStaff.Enabled = false;
            tbStaff.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbStaff.Location = new Point(749, 541);
            tbStaff.Name = "tbStaff";
            tbStaff.Size = new Size(176, 25);
            tbStaff.TabIndex = 42;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label17.Location = new Point(651, 544);
            label17.Name = "label17";
            label17.Size = new Size(93, 15);
            label17.TabIndex = 41;
            label17.Text = "Người thực hiện";
            // 
            // dtpkUpdate
            // 
            dtpkUpdate.Location = new Point(749, 512);
            dtpkUpdate.Name = "dtpkUpdate";
            dtpkUpdate.Size = new Size(176, 23);
            dtpkUpdate.TabIndex = 40;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.Location = new Point(655, 515);
            label16.Name = "label16";
            label16.Size = new Size(85, 15);
            label16.TabIndex = 39;
            label16.Text = "Ngày cập nhật";
            // 
            // panel3
            // 
            panel3.Controls.Add(dtgv_list);
            panel3.Location = new Point(327, 58);
            panel3.Name = "panel3";
            panel3.Size = new Size(607, 448);
            panel3.TabIndex = 37;
            // 
            // dtgv_list
            // 
            dtgv_list.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgv_list.Location = new Point(8, 9);
            dtgv_list.Name = "dtgv_list";
            dtgv_list.RowHeadersWidth = 51;
            dtgv_list.RowTemplate.Height = 24;
            dtgv_list.Size = new Size(590, 436);
            dtgv_list.TabIndex = 1;
            // 
            // UCDangKyDichVu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            Controls.Add(btnRemove);
            Controls.Add(label5);
            Controls.Add(btnAccept);
            Controls.Add(btnInfor);
            Controls.Add(lbHinhanh);
            Controls.Add(tbStaff);
            Controls.Add(label17);
            Controls.Add(dtpkUpdate);
            Controls.Add(label16);
            Controls.Add(panel3);
            Controls.Add(label1);
            Controls.Add(panelControl2);
            Controls.Add(label2);
            Name = "UCDangKyDichVu";
            Size = new Size(950, 580);
            panelControl2.ResumeLayout(false);
            panelControl2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgv_list).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Controls.PanelControl panelControl2;
        private Label label3;
        private TextBox tbName;
        private TextBox tbType;
        private TextBox tbColor;
        private Label label14;
        private TextBox tbEmail;
        private TextBox tbLicensePlate;
        private TextBox tbExpiration;
        private TextBox tbSdt;
        private TextBox tbAddress;
        private Label label12;
        private Label label4;
        private Label label6;
        private TextBox tbRegistration;
        private Label label7;
        private Label label8;
        private Label label11;
        private Label label9;
        private Label label10;
        private TextBox tbBrand;
        private Label label13;
        private Label label2;
        private Label label1;
        private Controls.Buttons btnRemove;
        private Label label5;
        private Controls.Buttons btnAccept;
        private Controls.Buttons btnInfor;
        private Label lbHinhanh;
        private TextBox tbStaff;
        private Label label17;
        private DateTimePicker dtpkUpdate;
        private Label label16;
        private Panel panel3;
        private DataGridView dtgv_list;
        private CheckBox cbElec;
    }
}
