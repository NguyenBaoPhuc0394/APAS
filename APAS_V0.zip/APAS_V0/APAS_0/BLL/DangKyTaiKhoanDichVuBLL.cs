﻿using APAS_0.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APAS_0.BLL
{
    public class DangKyTaiKhoanDichVuBLL
    {
        #region Singleton dp
        private static DangKyTaiKhoanDichVuBLL instance;

        public static DangKyTaiKhoanDichVuBLL Instance
        {
            get
            {
                if (instance == null)
                    instance = new DangKyTaiKhoanDichVuBLL();
                return instance;
            }
            set => instance = value;
        }

        private DangKyTaiKhoanDichVuBLL() { }
        #endregion
    }
}
