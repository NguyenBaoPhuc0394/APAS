﻿using System.Drawing;
using System.Windows.Forms;

namespace APAS_0
{
    partial class FOTP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FOTP));
            panel2 = new Panel();
            buttons2 = new Controls.Buttons();
            pictureBox1 = new PictureBox();
            textBox1 = new TextBox();
            label3 = new Label();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(46, 177, 255);
            panel2.BackgroundImageLayout = ImageLayout.Zoom;
            panel2.Controls.Add(buttons2);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(textBox1);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(457, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(345, 416);
            panel2.TabIndex = 3;
            // 
            // buttons2
            // 
            buttons2.BackColor = Color.MediumSlateBlue;
            buttons2.BackgroundColor = Color.MediumSlateBlue;
            buttons2.BorderColor = Color.PaleVioletRed;
            buttons2.BorderRadius = 20;
            buttons2.BorderSize = 0;
            buttons2.FlatAppearance.BorderSize = 0;
            buttons2.FlatStyle = FlatStyle.Flat;
            buttons2.Font = new Font("Verdana", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttons2.ForeColor = Color.White;
            buttons2.Location = new Point(100, 217);
            buttons2.Name = "buttons2";
            buttons2.Size = new Size(144, 40);
            buttons2.TabIndex = 16;
            buttons2.Text = "Xác nhận";
            buttons2.TextColor = Color.White;
            buttons2.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(34, 161);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(33, 32);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(70, 166);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(240, 23);
            textBox1.TabIndex = 2;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(67, 143);
            label3.Name = "label3";
            label3.Size = new Size(58, 16);
            label3.TabIndex = 1;
            label3.Text = "Mã OTP";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Courier New", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(101, 85);
            label2.Name = "label2";
            label2.Size = new Size(142, 31);
            label2.TabIndex = 0;
            label2.Text = "NHẬP OTP";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(457, 416);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // OTP
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 416);
            Controls.Add(panel2);
            Controls.Add(pictureBox2);
            Name = "OTP";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "OTP";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Controls.Buttons buttons2;
        private PictureBox pictureBox1;
        private TextBox textBox1;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox2;
    }
}