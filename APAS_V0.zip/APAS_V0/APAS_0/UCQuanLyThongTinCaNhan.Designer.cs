﻿namespace APAS_0
{
    partial class UCQuanLyThongTinCaNhan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCQuanLyThongTinCaNhan));
            panelControl2 = new Controls.PanelControl();
            label3 = new Label();
            tbName = new TextBox();
            tbType = new TextBox();
            tbColor = new TextBox();
            tbEmail = new TextBox();
            tbSdt = new TextBox();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            textBox1 = new TextBox();
            label2 = new Label();
            panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panelControl2
            // 
            panelControl2.BackColor = Color.FromArgb(69, 197, 149);
            panelControl2.BorderRadius = 50;
            panelControl2.Controls.Add(textBox1);
            panelControl2.Controls.Add(label2);
            panelControl2.Controls.Add(label3);
            panelControl2.Controls.Add(tbName);
            panelControl2.Controls.Add(tbType);
            panelControl2.Controls.Add(tbColor);
            panelControl2.Controls.Add(tbEmail);
            panelControl2.Controls.Add(tbSdt);
            panelControl2.Controls.Add(label4);
            panelControl2.Controls.Add(label6);
            panelControl2.Controls.Add(label7);
            panelControl2.Controls.Add(label8);
            panelControl2.Controls.Add(label9);
            panelControl2.Location = new Point(327, 118);
            panelControl2.Name = "panelControl2";
            panelControl2.Size = new Size(344, 322);
            panelControl2.TabIndex = 38;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(82, 27);
            label3.Name = "label3";
            label3.Size = new Size(180, 24);
            label3.TabIndex = 30;
            label3.Text = "Thông tin cá nhân";
            // 
            // tbName
            // 
            tbName.Location = new Point(126, 71);
            tbName.Name = "tbName";
            tbName.Size = new Size(204, 23);
            tbName.TabIndex = 1;
            // 
            // tbType
            // 
            tbType.Location = new Point(126, 231);
            tbType.Name = "tbType";
            tbType.Size = new Size(204, 23);
            tbType.TabIndex = 4;
            // 
            // tbColor
            // 
            tbColor.Location = new Point(126, 271);
            tbColor.Name = "tbColor";
            tbColor.Size = new Size(204, 23);
            tbColor.TabIndex = 5;
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(126, 191);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(204, 23);
            tbEmail.TabIndex = 3;
            // 
            // tbSdt
            // 
            tbSdt.Location = new Point(126, 111);
            tbSdt.Name = "tbSdt";
            tbSdt.Size = new Size(204, 23);
            tbSdt.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9.75F);
            label4.Location = new Point(25, 74);
            label4.Name = "label4";
            label4.Size = new Size(86, 16);
            label4.TabIndex = 12;
            label4.Text = "Mã nhân viên";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9.75F);
            label6.Location = new Point(22, 114);
            label6.Name = "label6";
            label6.Size = new Size(91, 16);
            label6.TabIndex = 13;
            label6.Text = "Tên nhân viên";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9.75F);
            label7.Location = new Point(67, 194);
            label7.Name = "label7";
            label7.Size = new Size(41, 16);
            label7.TabIndex = 14;
            label7.Text = "Email";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9.75F);
            label8.Location = new Point(27, 234);
            label8.Name = "label8";
            label8.Size = new Size(85, 16);
            label8.TabIndex = 15;
            label8.Text = "Số điện thoại";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9.75F);
            label9.Location = new Point(56, 274);
            label9.Name = "label9";
            label9.Size = new Size(54, 16);
            label9.TabIndex = 16;
            label9.Text = "Chức vụ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(169, 145);
            label1.Name = "label1";
            label1.Size = new Size(68, 24);
            label1.TabIndex = 31;
            label1.Text = "Avatar";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(116, 189);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(182, 191);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 39;
            pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(126, 151);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(204, 23);
            textBox1.TabIndex = 31;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 9.75F);
            label2.Location = new Point(16, 154);
            label2.Name = "label2";
            label2.Size = new Size(98, 16);
            label2.TabIndex = 32;
            label2.Text = "Tên đăng nhập";
            // 
            // UCQuanLyThongTinCaNhan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(panelControl2);
            Name = "UCQuanLyThongTinCaNhan";
            Size = new Size(950, 580);
            panelControl2.ResumeLayout(false);
            panelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Controls.PanelControl panelControl2;
        private Label label3;
        private TextBox tbName;
        private TextBox tbType;
        private TextBox tbColor;
        private TextBox tbEmail;
        private TextBox tbSdt;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label1;
        private PictureBox pictureBox1;
        private TextBox textBox1;
        private Label label2;
    }
}
