﻿namespace APAS_0
{
    partial class UCQuanLyDichVu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnDelete = new Controls.Buttons();
            btnUpdate = new Controls.Buttons();
            btnAdd = new Controls.Buttons();
            tbStaff = new TextBox();
            label17 = new Label();
            dtpkUpdate = new DateTimePicker();
            label16 = new Label();
            panelControl2 = new Controls.PanelControl();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            label3 = new Label();
            tbName = new TextBox();
            tbType = new TextBox();
            tbColor = new TextBox();
            label14 = new Label();
            tbEmail = new TextBox();
            tbLicensePlate = new TextBox();
            tbSdt = new TextBox();
            tbAddress = new TextBox();
            label12 = new Label();
            label4 = new Label();
            label6 = new Label();
            tbRegistration = new TextBox();
            label7 = new Label();
            label8 = new Label();
            label11 = new Label();
            label9 = new Label();
            label10 = new Label();
            tbBrand = new TextBox();
            label13 = new Label();
            label5 = new Label();
            panel3 = new Panel();
            dtgvTK = new DataGridView();
            panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dtgvTK).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(370, 10);
            label1.Name = "label1";
            label1.Size = new Size(211, 25);
            label1.TabIndex = 59;
            label1.Text = "QUẢN LÝ DỊCH VỤ";
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(255, 75, 8);
            btnDelete.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnDelete.BorderColor = Color.PaleVioletRed;
            btnDelete.BorderColor1 = Color.PaleVioletRed;
            btnDelete.BorderRadius = 20;
            btnDelete.BorderRadius1 = 20;
            btnDelete.BorderSize = 0;
            btnDelete.BorderSize1 = 0;
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(548, 517);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(99, 40);
            btnDelete.TabIndex = 66;
            btnDelete.Text = "Xoá";
            btnDelete.TextColor = Color.White;
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(255, 75, 8);
            btnUpdate.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnUpdate.BorderColor = Color.PaleVioletRed;
            btnUpdate.BorderColor1 = Color.PaleVioletRed;
            btnUpdate.BorderRadius = 20;
            btnUpdate.BorderRadius1 = 20;
            btnUpdate.BorderSize = 0;
            btnUpdate.BorderSize1 = 0;
            btnUpdate.FlatAppearance.BorderSize = 0;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.ForeColor = Color.White;
            btnUpdate.Location = new Point(443, 517);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(99, 40);
            btnUpdate.TabIndex = 65;
            btnUpdate.Text = "Sửa";
            btnUpdate.TextColor = Color.White;
            btnUpdate.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(255, 75, 8);
            btnAdd.BackgroundColor = Color.FromArgb(255, 75, 8);
            btnAdd.BorderColor = Color.PaleVioletRed;
            btnAdd.BorderColor1 = Color.PaleVioletRed;
            btnAdd.BorderRadius = 20;
            btnAdd.BorderRadius1 = 20;
            btnAdd.BorderSize = 0;
            btnAdd.BorderSize1 = 0;
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(341, 517);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(99, 40);
            btnAdd.TabIndex = 60;
            btnAdd.Text = "Thêm";
            btnAdd.TextColor = Color.White;
            btnAdd.UseVisualStyleBackColor = false;
            // 
            // tbStaff
            // 
            tbStaff.Enabled = false;
            tbStaff.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tbStaff.Location = new Point(754, 546);
            tbStaff.Name = "tbStaff";
            tbStaff.Size = new Size(176, 25);
            tbStaff.TabIndex = 64;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label17.Location = new Point(657, 550);
            label17.Name = "label17";
            label17.Size = new Size(98, 16);
            label17.TabIndex = 63;
            label17.Text = "Người thực hiện";
            // 
            // dtpkUpdate
            // 
            dtpkUpdate.Location = new Point(754, 517);
            dtpkUpdate.Name = "dtpkUpdate";
            dtpkUpdate.Size = new Size(176, 23);
            dtpkUpdate.TabIndex = 62;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.Location = new Point(657, 520);
            label16.Name = "label16";
            label16.Size = new Size(94, 16);
            label16.TabIndex = 61;
            label16.Text = "Ngày cập nhật";
            // 
            // panelControl2
            // 
            panelControl2.BackColor = Color.FromArgb(69, 197, 149);
            panelControl2.BorderRadius = 50;
            panelControl2.Controls.Add(pictureBox1);
            panelControl2.Controls.Add(button1);
            panelControl2.Controls.Add(label3);
            panelControl2.Controls.Add(tbName);
            panelControl2.Controls.Add(tbType);
            panelControl2.Controls.Add(tbColor);
            panelControl2.Controls.Add(label14);
            panelControl2.Controls.Add(tbEmail);
            panelControl2.Controls.Add(tbLicensePlate);
            panelControl2.Controls.Add(tbSdt);
            panelControl2.Controls.Add(tbAddress);
            panelControl2.Controls.Add(label12);
            panelControl2.Controls.Add(label4);
            panelControl2.Controls.Add(label6);
            panelControl2.Controls.Add(tbRegistration);
            panelControl2.Controls.Add(label7);
            panelControl2.Controls.Add(label8);
            panelControl2.Controls.Add(label11);
            panelControl2.Controls.Add(label9);
            panelControl2.Controls.Add(label10);
            panelControl2.Controls.Add(tbBrand);
            panelControl2.Controls.Add(label13);
            panelControl2.Location = new Point(17, 51);
            panelControl2.Name = "panelControl2";
            panelControl2.Size = new Size(318, 520);
            panelControl2.TabIndex = 67;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(112, 432);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(186, 74);
            pictureBox1.TabIndex = 32;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 75, 8);
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(31, 466);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 31;
            button1.Text = "Chọn hình";
            button1.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(111, 31);
            label3.Name = "label3";
            label3.Size = new Size(99, 24);
            label3.TabIndex = 30;
            label3.Text = "Thông tin";
            // 
            // tbName
            // 
            tbName.Location = new Point(111, 76);
            tbName.Name = "tbName";
            tbName.Size = new Size(187, 23);
            tbName.TabIndex = 1;
            // 
            // tbType
            // 
            tbType.Location = new Point(111, 196);
            tbType.Name = "tbType";
            tbType.Size = new Size(187, 23);
            tbType.TabIndex = 4;
            // 
            // tbColor
            // 
            tbColor.Location = new Point(111, 236);
            tbColor.Name = "tbColor";
            tbColor.Size = new Size(187, 23);
            tbColor.TabIndex = 5;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Microsoft Sans Serif", 9F);
            label14.Location = new Point(14, 445);
            label14.Name = "label14";
            label14.Size = new Size(92, 15);
            label14.TabIndex = 27;
            label14.Text = "Hình biển số xe";
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(111, 156);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(187, 23);
            tbEmail.TabIndex = 3;
            // 
            // tbLicensePlate
            // 
            tbLicensePlate.Location = new Point(111, 276);
            tbLicensePlate.Name = "tbLicensePlate";
            tbLicensePlate.Size = new Size(187, 23);
            tbLicensePlate.TabIndex = 6;
            // 
            // tbSdt
            // 
            tbSdt.Location = new Point(111, 116);
            tbSdt.Name = "tbSdt";
            tbSdt.Size = new Size(187, 23);
            tbSdt.TabIndex = 2;
            // 
            // tbAddress
            // 
            tbAddress.Location = new Point(111, 316);
            tbAddress.Name = "tbAddress";
            tbAddress.Size = new Size(187, 23);
            tbAddress.TabIndex = 8;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 9F);
            label12.Location = new Point(66, 400);
            label12.Name = "label12";
            label12.Size = new Size(40, 15);
            label12.TabIndex = 25;
            label12.Text = "ZONE";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F);
            label4.Location = new Point(44, 80);
            label4.Name = "label4";
            label4.Size = new Size(62, 15);
            label4.TabIndex = 12;
            label4.Text = "Họ và Tên";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9F);
            label6.Location = new Point(75, 120);
            label6.Name = "label6";
            label6.Size = new Size(31, 15);
            label6.TabIndex = 13;
            label6.Text = "SĐT";
            // 
            // tbRegistration
            // 
            tbRegistration.Location = new Point(111, 396);
            tbRegistration.Name = "tbRegistration";
            tbRegistration.Size = new Size(187, 23);
            tbRegistration.TabIndex = 24;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9F);
            label7.Location = new Point(67, 160);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 14;
            label7.Text = "Email";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F);
            label8.Location = new Point(59, 200);
            label8.Name = "label8";
            label8.Size = new Size(47, 15);
            label8.TabIndex = 15;
            label8.Text = "Loại xe";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Microsoft Sans Serif", 9F);
            label11.Location = new Point(3, 364);
            label11.Name = "label11";
            label11.Size = new Size(103, 15);
            label11.TabIndex = 23;
            label11.Text = "Loại hình đăng ký";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9F);
            label9.Location = new Point(58, 240);
            label9.Name = "label9";
            label9.Size = new Size(48, 15);
            label9.TabIndex = 16;
            label9.Text = "Màu xe";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 9F);
            label10.Location = new Point(42, 280);
            label10.Name = "label10";
            label10.Size = new Size(64, 15);
            label10.TabIndex = 17;
            label10.Text = "Biển số xe";
            // 
            // tbBrand
            // 
            tbBrand.Location = new Point(111, 356);
            tbBrand.Name = "tbBrand";
            tbBrand.Size = new Size(187, 23);
            tbBrand.TabIndex = 22;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Sans Serif", 9F);
            label13.Location = new Point(61, 320);
            label13.Name = "label13";
            label13.Size = new Size(45, 15);
            label13.TabIndex = 21;
            label13.Text = "Địa chỉ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(356, 51);
            label5.Name = "label5";
            label5.Size = new Size(133, 16);
            label5.TabIndex = 38;
            label5.Text = "Danh sách dịch vụ";
            // 
            // panel3
            // 
            panel3.Controls.Add(dtgvTK);
            panel3.Location = new Point(348, 60);
            panel3.Name = "panel3";
            panel3.Size = new Size(607, 448);
            panel3.TabIndex = 39;
            // 
            // dtgvTK
            // 
            dtgvTK.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtgvTK.Location = new Point(8, 9);
            dtgvTK.Name = "dtgvTK";
            dtgvTK.RowHeadersWidth = 51;
            dtgvTK.RowTemplate.Height = 24;
            dtgvTK.Size = new Size(590, 436);
            dtgvTK.TabIndex = 1;
            // 
            // UCQuanLyDichVu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(178, 210, 182);
            Controls.Add(label5);
            Controls.Add(panel3);
            Controls.Add(panelControl2);
            Controls.Add(label1);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(tbStaff);
            Controls.Add(label17);
            Controls.Add(dtpkUpdate);
            Controls.Add(label16);
            Name = "UCQuanLyDichVu";
            Size = new Size(950, 580);
            Load += UCQuanLyDichVu_Load;
            panelControl2.ResumeLayout(false);
            panelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dtgvTK).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Controls.Buttons btnDelete;
        private Controls.Buttons btnUpdate;
        private Controls.Buttons btnAdd;
        private TextBox tbStaff;
        private Label label17;
        private DateTimePicker dtpkUpdate;
        private Label label16;
        private Controls.PanelControl panelControl2;
        private Label label3;
        private TextBox tbName;
        private TextBox tbType;
        private TextBox tbColor;
        private Label label14;
        private TextBox tbEmail;
        private TextBox tbLicensePlate;
        private TextBox tbSdt;
        private TextBox tbAddress;
        private Label label12;
        private Label label4;
        private Label label6;
        private TextBox tbRegistration;
        private Label label7;
        private Label label8;
        private Label label11;
        private Label label9;
        private Label label10;
        private TextBox tbBrand;
        private Label label13;
        private PictureBox pictureBox1;
        private Button button1;
        private Label label5;
        private Panel panel3;
        private DataGridView dtgvTK;
    }
}
